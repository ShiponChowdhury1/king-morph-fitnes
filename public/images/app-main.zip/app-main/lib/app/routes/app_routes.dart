class AppRoutes {
  AppRoutes._();

  static const String splash = '/splash';
  static const String login = '/login';
  static const String products = '/products';
  static const String getStarted = '/get-started';
  static const String welcome = '/welcome';
  static const String onboarding = '/onboarding';
  static const String signup = '/signup';
  static const String emailVerification = '/email-verification';
  static const String congratulation = '/congratulation';
  static const String forgotPassword = '/forgot-password';
  static const String resetPassword = '/reset-password';
  static const String otpVerification = '/otp-verification';
  static const String selectGender = '/select-gender';
  static const String malePage = '/male-page';
  static const String femalePage = '/female-page';

  static const String mainApp = '/main-app';
  static const String notification = '/notification';
  static const String yourProgram = '/your-program';
  static const String nutritionPlan = '/nutritionPlan';
  static const String progress = '/progress';
}
