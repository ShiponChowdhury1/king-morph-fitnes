import 'package:demo_project/app/features/forget/binding/forget_binding.dart';
import 'package:demo_project/app/features/forget/view/forgat_page.dart';
import 'package:demo_project/app/features/forget/view/reset_password_page.dart';
import 'package:demo_project/app/features/main/binding/main_app_binding.dart';
import 'package:demo_project/app/features/main/view/main_app.dart';
import 'package:demo_project/app/features/notification/binding/notification_binding.dart';
import 'package:demo_project/app/features/notification/view/notification_page.dart';
import 'package:demo_project/app/features/progress/binding/progress_binding.dart';
import 'package:demo_project/app/features/progress/view/progress_page.dart';
import 'package:demo_project/app/features/setupProfile/binding/setup_binding.dart';
import 'package:demo_project/app/features/setupProfile/view/selected_gender_page.dart';
import 'package:demo_project/app/features/setupProfile/view/MalePage/male_page.dart';
import 'package:demo_project/app/features/setupProfile/view/FemalePage/female_page.dart';
import 'package:demo_project/app/features/workout/binding/workout_binding.dart';
import 'package:demo_project/app/features/workout/view/YourProgram/your_program_page.dart';
import '../features/forget/view/otp_verify_page.dart';
import '../features/signup/binding/signup_binding.dart';
import 'package:demo_project/app/features/signup/view/signup_page.dart';
import 'package:get/get.dart';

import 'package:demo_project/app/features/login/binding/login_binding.dart';
import 'package:demo_project/app/features/login/view/login_page.dart';
import 'package:demo_project/app/features/products/binding/products_binding.dart';
import 'package:demo_project/app/features/products/view/products_page.dart';
import 'package:demo_project/app/features/splash/getstarted_page.dart';
import 'package:demo_project/app/features/splash/onboarding_page.dart';
import 'package:demo_project/app/features/splash/splash_page.dart';
import 'package:demo_project/app/features/splash/welcome_page.dart';
import 'package:demo_project/app/routes/app_routes.dart';
import 'package:demo_project/app/routes/auth_middleware.dart';

import '../features/emailVerify/binding/email_binding.dart';

import '../features/emailVerify/view/congratulation_page.dart';
import '../features/emailVerify/view/email_verify_page.dart';
import '../features/splash/binding/splash_binding.dart';

class AppPages {
  AppPages._();

  static const initial = AppRoutes.splash;

  static final pages = <GetPage>[
    // ── Splash ───────────────────────────────────────────────────────────
    GetPage(
      name: AppRoutes.splash,
      page: () => const SplashPage(),
      binding: SplashBinding(),
    ),

    GetPage(
      name: AppRoutes.getStarted,
      page: () => const GetstartedPage(),
      binding: SplashBinding(),
    ),

    GetPage(
      name: AppRoutes.welcome,
      page: () => const WelcomePage(),
      binding: SplashBinding(),
    ),

    GetPage(
      name: AppRoutes.onboarding,
      page: () => const OnboardingPage(),
      binding: SplashBinding(),
    ),

    // ── Login ────────────────────────────────────────────────────────────
    GetPage(
      name: AppRoutes.login,
      page: () => const LoginPage(),
      binding: LoginBinding(),
    ),

    GetPage(
      name: AppRoutes.signup,
      page: () => const SignupPage(),
      binding: SignupBinding(),
    ),

    GetPage(
      name: AppRoutes.emailVerification,
      page: () => const EmailVerifyPage(),
      binding: EmailBinding(),
    ),

    GetPage(
      name: AppRoutes.congratulation,
      page: () => const CongratulationPage(),
    ),
    GetPage(
      name: AppRoutes.forgotPassword,
      page: () => const ForgetPage(),
      binding: ForgetBinding(),
    ),
    GetPage(
      name: AppRoutes.otpVerification,
      page: () => const OtpVerifyPage(),
      binding: ForgetBinding(),
    ),
    GetPage(
      name: AppRoutes.resetPassword,
      page: () => const ResetPasswordPage(),
      binding: ForgetBinding(),
    ),

    // ── Products ─────────────────────────────────────────────────────────
    GetPage(
      name: AppRoutes.selectGender,
      page: () => SelectedGenderPage(),
      binding: SetupBinding(),
    ),
    GetPage(
      name: AppRoutes.malePage,
      page: () => const MalePage(),
      binding: SetupBinding(),
    ),
    GetPage(
      name: AppRoutes.femalePage,
      page: () => const FemalePage(),
      binding: SetupBinding(),
    ),
       GetPage(
      name: AppRoutes.mainApp,
      page: () => MainApp(),
      binding: MainAppBinding(),
    ),
         GetPage(
      name: AppRoutes.notification,
      page: () => NotificationPage(),
      binding: NotificationBinding(),
    ),

           GetPage(
      name: AppRoutes.yourProgram,
      page: () => YourProgramPage(),
      binding: WorkoutBinding(),
    ),
    GetPage(
      name: AppRoutes.progress,
      page: () => const ProgressPage(),
      binding: ProgressBinding(),
    ),
  
  ];
}
