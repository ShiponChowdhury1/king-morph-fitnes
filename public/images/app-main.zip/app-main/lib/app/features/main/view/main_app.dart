import 'package:demo_project/app/features/home/view/home_page.dart';
import 'package:demo_project/app/features/nutrition/view/nutrition_plan_page.dart';
import 'package:demo_project/app/features/profile/view/profile_page.dart';
import 'package:demo_project/app/features/progress/view/progress_page.dart';
import 'package:demo_project/app/features/workout/view/YourProgram/your_program_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:demo_project/app/features/main/controller/main_app_controller.dart';

class MainApp extends GetView<MainAppController> {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Obx(() {
        switch (controller.currentIndex.value) {
          case 0:
            return HomePage();
          case 1:
            return YourProgramPage();
          case 2:
            return NutritionPlanPage();
          case 3:
            return ProgressPage();
          case 4:
            return ProfilePage();
          default:
            return const Center(child: Text('Home Page'));
        }
      }),
      bottomNavigationBar: Obx(
        () => Container(
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border(
              top: BorderSide(color: Colors.grey.shade200, width: 1.0),
            ),
          ),
          child: Theme(
            data: ThemeData(
              splashColor: Colors.transparent,
              highlightColor: Colors.transparent,
            ),
            child: BottomNavigationBar(
              currentIndex: controller.currentIndex.value,
              onTap: controller.changePage,
              type: BottomNavigationBarType.fixed,
              backgroundColor: Colors.white,
              selectedItemColor: Colors.black,
              unselectedItemColor: const Color(0xFFA1A1A1),
              showSelectedLabels: true,
              showUnselectedLabels: true,
              selectedLabelStyle: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                fontFamily: 'Poppins',
              ),
              unselectedLabelStyle: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w500,
                fontFamily: 'Poppins',
              ),
              elevation: 0,
              items: [
                _buildNavigationBarItem(
                  iconPath: 'assets/icons/home.svg',
                  label: 'Home',
                  index: 0,
                ),
                _buildNavigationBarItem(
                  iconPath: 'assets/icons/workout.svg',
                  label: 'Workout',
                  index: 1,
                ),
                _buildNavigationBarItem(
                  iconPath: 'assets/icons/apple.svg',
                  label: 'Nutrition',
                  index: 2,
                ),
                _buildNavigationBarItem(
                  iconPath: 'assets/icons/progress.svg',
                  label: 'Progress',
                  index: 3,
                ),
                _buildNavigationBarItem(
                  iconPath: 'assets/icons/profile.svg',
                  label: 'Profile',
                  index: 4,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  BottomNavigationBarItem _buildNavigationBarItem({
    required String iconPath,
    required String label,
    required int index,
  }) {
    final isSelected = controller.currentIndex.value == index;
    final color = isSelected ? Colors.black : const Color(0xFFA1A1A1);

    return BottomNavigationBarItem(
      icon: Padding(
        padding: const EdgeInsets.only(bottom: 4.0),
        child: SvgPicture.asset(
          iconPath,
          colorFilter: ColorFilter.mode(color, BlendMode.srcIn),
          height: 24,
          width: 24,
        ),
      ),
      label: label,
    );
  }
}
