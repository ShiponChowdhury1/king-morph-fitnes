import 'package:demo_project/app/features/main/controller/main_app_controller.dart';
import 'package:get/get.dart';

class MainAppBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<MainAppController>(() => MainAppController());
  }
}