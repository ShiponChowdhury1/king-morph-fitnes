import 'package:get/get.dart';

class ProfileController extends GetxController {
  final RxBool isNotificationsEnabled = true.obs;

  void toggleNotifications(bool value) {
    isNotificationsEnabled.value = value;
  }
}