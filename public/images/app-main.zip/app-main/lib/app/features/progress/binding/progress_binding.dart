import 'package:demo_project/app/features/progress/controller/progress_controller.dart';
import 'package:get/get.dart';

class ProgressBinding extends Bindings{
  @override
  void dependencies() {
    Get.lazyPut(() => ProgressController());
  }
}