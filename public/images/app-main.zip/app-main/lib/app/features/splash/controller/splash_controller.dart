import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../routes/app_routes.dart';

class SplashController extends GetxController {
  final PageController pageController = PageController();
  final RxInt currentPage = 0.obs;

  final List<Map<String, String>> onboardingData = [
    {
      'image': 'assets/images/dummy1.png',
      'title': 'Start your journey towards a more active lifestyle',
      'description': 'Small steps lead to big changes',
      'button': 'Next',
    },
    {
      'image': 'assets/images/dummy2.png',
      'title': 'Find nutrition tips that fit your lifestyle',
      'description': 'Personalized nutritional guidance',
      'button': 'Next',
    },
    {
      'image': 'assets/images/dummy3.png',
      'title': 'Personalized training and AI coach',
      'description': 'Tailored to user\'s body type and fitness goal',
      'button': 'Start Training',
    },
  ];

  void onPageChanged(int index) {
    currentPage.value = index;
  }

  void nextPage() {
    if (currentPage.value < onboardingData.length - 1) {
      pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    } else {
      skip();
    }
  }

  void skip() {
    Get.offAllNamed(AppRoutes.login);
  }

  void goToGetStarted() {
    Get.toNamed(AppRoutes.getStarted);
  }

  void goToOnboarding() {
    Get.toNamed(AppRoutes.onboarding);
  }

  @override
  void onClose() {
    pageController.dispose();
    super.onClose();
  }
}
