import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:demo_project/app/core/theme/app_colors.dart';
import 'package:demo_project/app/core/widgets/custom_button.dart';
import 'package:demo_project/app/routes/app_routes.dart';

class CongratulationPage extends StatelessWidget {
  const CongratulationPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(),
              // Title
              const Text(
                "Email Verified!",
                style: TextStyle(
                  fontSize: 27,
                  fontWeight: FontWeight.w600,
                  color: AppColors.lightTextPrimary,
                  fontFamily: 'Poppins',
                ),
              ),
              const SizedBox(height: 9),
              // Subtitle
              const Text(
                "Start your journey with kingmorph",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  color: Color(0xFF0B0616),
                  fontFamily: 'Poppins',
                ),
              ),
              const SizedBox(height: 90),

              // Success Illustration
              Image.asset(
                "assets/images/verified.png",
                width: Get.width * 0.8,
                fit: BoxFit.contain,
              ),

              const Spacer(),

              // Next Button
              CustomButton(
                text: "Next",
                onPressed: () {
                  Get.toNamed(AppRoutes.selectGender);
                },
              ),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}
