import 'package:demo_project/app/features/emailVerify/view/congratulation_page.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:demo_project/app/core/theme/app_colors.dart';
import 'package:demo_project/app/core/widgets/custom_button.dart';
import 'package:demo_project/app/features/emailVerify/controller/email_verify_controller.dart';

class EmailVerifyPage extends GetView<EmailVerifyController> {
  const EmailVerifyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Get.back(),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 20),
              // Title
              const Text(
                "Email verification",
                style: TextStyle(
                  fontSize: 27,
                  fontWeight: FontWeight.w600,
                  color: AppColors.lightTextPrimary,
                  fontFamily: 'Poppins',
                ),
              ),
              const SizedBox(height: 9),
              // Subtitle
              const Text(
                "We sent a verification code to your email",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Color(0xFF0B0616),
                  fontFamily: 'Poppins',
                ),
              ),
              const SizedBox(height: 40),

              // OTP Fields
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: List.generate(
                  6,
                  (index) => SizedBox(
                    width: 48,
                    height: 56,
                    child: TextField(
                      controller: controller.otpControllers[index],
                      focusNode: controller.focusNodes[index],
                      onChanged: (value) {
                        if (value.isNotEmpty && index < 5) {
                          controller.focusNodes[index + 1].requestFocus();
                        } else if (value.isEmpty && index > 0) {
                          controller.focusNodes[index - 1].requestFocus();
                        }
                      },
                      textAlign: TextAlign.center,
                      keyboardType: TextInputType.number,
                      maxLength: 1,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Poppins',
                      ),
                      decoration: InputDecoration(
                        counterText: "",
                        contentPadding: EdgeInsets.zero,
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(color: Colors.grey.shade200, width: 1.5),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Colors.black, width: 1.5),
                        ),
                        fillColor: const Color(0xFFFDFDFD),
                        filled: true,
                      ),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 32),

              // Resend Text
              Obx(() => Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        "Don't receive your code? ",
                        style: TextStyle(
                          color: Color(0xFF0B0616),
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          fontFamily: 'Poppins',
                        ),
                      ),
                      GestureDetector(
                        onTap: controller.timerSeconds.value == 0 ? controller.resendCode : null,
                        child: Text(
                          controller.timerSeconds.value > 0
                              ? "Resend(${controller.timerSeconds.value}s)"
                              : "Resend Code",
                          style: const TextStyle(
                            color: Color(0xFF3D37F1),
                            fontWeight: FontWeight.w500,
                            fontSize: 16,
                            fontFamily: 'Poppins',
                          ),
                        ),
                      ),
                    ],
                  )),

              const SizedBox(height: 68),

              // Verify Button
              CustomButton(
                text: "Verify OTP",
                onPressed:(){
                  Get.to(()=> CongratulationPage());
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
