import 'package:demo_project/app/features/nutrition/controller/nutrition_plan_controller.dart';
import 'package:get/get.dart';

class NutritionPlanBinding extends Bindings{
  @override
  void dependencies() {
    Get.lazyPut(() => NutritionPlanController());
  }
}