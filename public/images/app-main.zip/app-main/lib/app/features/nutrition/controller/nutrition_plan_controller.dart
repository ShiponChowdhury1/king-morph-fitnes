import 'package:get/get.dart';

class NutritionPlanController extends GetxController {
  final RxString selectedTab = 'All'.obs;
  
  final List<String> tabs = ['All', 'Breakfast', 'Lunch', 'Dinner'];

  void selectTab(String tab) {
    selectedTab.value = tab;
  }
}