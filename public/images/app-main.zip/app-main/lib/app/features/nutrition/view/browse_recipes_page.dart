import 'package:demo_project/app/features/nutrition/view/recipes_details_page.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controller/nutrition_plan_controller.dart';

class BrowseRecipesPage extends StatelessWidget {
  const BrowseRecipesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(NutritionPlanController());
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Browse recipes',
          style: TextStyle(
            color: Colors.black,
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: false,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Top Recipes',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Colors.black,
                  ),
                ),
                GestureDetector(
                  onTap: () {},
                  child: const Row(
                    children: [
                      Text(
                        'See All',
                        style: TextStyle(fontSize: 12, color: Colors.grey),
                      ),
                      Icon(Icons.chevron_right, size: 16, color: Colors.grey),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Banner
            Container(
              height: 120,
              decoration: BoxDecoration(
                color: const Color(0xFF111111),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  Expanded(
                    flex: 3,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            'Personalized\nMeal Recipes',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              height: 1.2,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: const Text(
                              'Browse recipes',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: ClipRRect(
                      borderRadius: const BorderRadius.only(
                        topRight: Radius.circular(16),
                        bottomRight: Radius.circular(16),
                      ),
                      child: Image.asset(
                        'assets/images/lunch.jpg',
                        fit: BoxFit.cover,
                        height: double.infinity,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Filters
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Obx(
                () => Row(
                  children: controller.tabs.map((tab) {
                    return Padding(
                      padding: const EdgeInsets.only(right: 8.0),
                      child: GestureDetector(
                        onTap: () => controller.selectTab(tab),
                        child: _buildFilterChip(
                          tab,
                          controller.selectedTab.value == tab,
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),

            const SizedBox(height: 24),

            // Grid
            Builder(
              builder: (context) {
                final List<Map<String, String>> recipes = [
                  {
                    'image': 'assets/images/vegitable.jpg',
                    'title':
                        'Roasted Cauliflower & Black Bean Burrito Bowl with Cilantro Li...',
                  },
                  {
                    'image': 'assets/images/pasta.jpg',
                    'title':
                        'Italian Pasta with Tomato & Basil (Pasta Pomodoro) and Garlic...',
                  },
                  {
                    'image': 'assets/images/meal.png',
                    'title':
                        'Indian Butter Chicken with Basmati Rice (Chicken Makhan...',
                  },
                  {
                    'image': 'assets/images/food.jpg',
                    'title':
                        'Greek Salad with Feta Cheese & Kalamata Olives (Greek Deligh...',
                  },
                  {
                    'image': 'assets/images/pasta.jpg',
                    'title':
                        'Italian Pasta with Tomato & Basil (Pasta Pomodoro) and Garlic...',
                  },
                  {
                    'image': 'assets/images/lunch.jpg',
                    'title':
                        'Creamy Cashew Zucchini Noodles with Vegan Sausage, Arti...',
                  },
                  {
                    'image': 'assets/images/meal.png',
                    'title':
                        'Indian Butter Chicken with Basmati Rice (Chicken Makhan...',
                  },
                  {
                    'image': 'assets/images/food.jpg',
                    'title':
                        'Greek Salad with Feta Cheese & Kalamata Olives (Greek Deligh...',
                  },
                  {
                    'image': 'assets/images/pasta.jpg',
                    'title':
                        'Italian Pasta with Tomato & Basil (Pasta Pomodoro) and Garlic...',
                  },
                  {
                    'image': 'assets/images/lunch.jpg',
                    'title':
                        'Creamy Cashew Zucchini Noodles with Vegan Sausage, Arti...',
                  },
                ];

                return GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 24,
                    childAspectRatio: 0.65,
                  ),
                  itemCount: recipes.length,
                  itemBuilder: (context, index) {
                    return _buildRecipeCard(
                      recipes[index]['image']!,
                      recipes[index]['title']!,
                    );
                  },
                );
              },
            ),

            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChip(String label, bool isSelected) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      decoration: BoxDecoration(
        color: isSelected ? Colors.black : Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: isSelected ? null : Border.all(color: Colors.grey[300]!),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: isSelected ? Colors.white : Colors.black,
          fontSize: 14,
          fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
        ),
      ),
    );
  }

  Widget _buildRecipeCard(String imagePath, String title) {
    return InkWell(
      onTap: () {
        Get.to(() => RecipesDetailsPage());
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: AspectRatio(
                  aspectRatio: 1,
                  child: Image.asset(imagePath, fit: BoxFit.cover),
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.add, size: 16, color: Colors.black),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            title,
            maxLines: 4,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 12,
              height: 1.3,
              fontWeight: FontWeight.w500,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }
}
