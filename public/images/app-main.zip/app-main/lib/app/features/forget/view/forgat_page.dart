import 'package:demo_project/app/core/widgets/custom_button.dart';
import 'package:demo_project/app/core/widgets/custom_text_field.dart';
import 'package:demo_project/app/features/forget/controller/forget_controller.dart';
import 'package:demo_project/app/features/forget/view/otp_verify_page.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ForgetPage extends GetView<ForgetController> {
  const ForgetPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Get.back(),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Form(
            key: controller.formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 100),
                // Title
                const Text(
                  "Reset your password",
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF0A0615),
                    fontFamily: 'Poppins',
                  ),
                ),
                const SizedBox(height: 12),
                // Subtitle
                const Text(
                  "Enter your email to reset your password.",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 14,
                    color: Color(0xFF404B52),
                    fontFamily: 'Poppins',
                  ),
                ),
                const SizedBox(height: 40),

                // Email Field
                CustomTextField(
                  controller: controller.emailController,
                  hintText: "Email",
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return "Please enter your email";
                    }
                    if (!GetUtils.isEmail(value)) {
                      return "Please enter a valid email";
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 32),

                // Send OTP Button
                CustomButton(
                  text: "Send OTP",
                  onPressed: (){
                    Get.to(()=> OtpVerifyPage());
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
