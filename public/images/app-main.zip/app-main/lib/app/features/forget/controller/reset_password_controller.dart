import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:demo_project/app/routes/app_routes.dart';

class ResetPasswordController extends GetxController {
  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController();
  final formKey = GlobalKey<FormState>();

  final RxBool isPasswordVisible = false.obs;
  final RxBool isConfirmPasswordVisible = false.obs;

  void togglePasswordVisibility() => isPasswordVisible.toggle();
  void toggleConfirmPasswordVisibility() => isConfirmPasswordVisible.toggle();

  void resetPassword() {
    if (formKey.currentState!.validate()) {
      // Logic to reset password
      Get.snackbar("Success", "Password reset successfully!");
      Get.offAllNamed(AppRoutes.login);
    }
  }

  @override
  void onClose() {
    passwordController.dispose();
    confirmPasswordController.dispose();
    super.onClose();
  }
}
