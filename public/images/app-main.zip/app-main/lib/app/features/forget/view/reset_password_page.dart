import 'package:demo_project/app/features/login/view/login_page.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:demo_project/app/core/widgets/custom_button.dart';
import 'package:demo_project/app/core/widgets/custom_text_field.dart';
import 'package:demo_project/app/features/forget/controller/reset_password_controller.dart';

class ResetPasswordPage extends GetView<ResetPasswordController> {
  const ResetPasswordPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Get.back(),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Form(
            key: controller.formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 20),
                // Title
                const Text(
                  "Reset password",
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF0A0615),
                    fontFamily: 'Poppins',
                  ),
                ),
                const SizedBox(height: 12),
                // Subtitle
                const Text(
                  "Create a new password that you will use to log in.",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 14,
                    color: Color(0xFF404B52),
                    fontFamily: 'Poppins',
                  ),
                ),
                const SizedBox(height: 40),

                // Password Field
                Obx(() => CustomTextField(
                      controller: controller.passwordController,
                      hintText: "New Password",
                      isPassword: !controller.isPasswordVisible.value,
                      suffixIcon: IconButton(
                        icon: Icon(
                          controller.isPasswordVisible.value
                              ? Icons.visibility
                              : Icons.visibility_off,
                          color: Colors.grey,
                        ),
                        onPressed: controller.togglePasswordVisibility,
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return "Please enter your password";
                        }
                        if (value.length < 6) {
                          return "Password must be at least 6 characters";
                        }
                        return null;
                      },
                    )),
                const SizedBox(height: 16),

                // Confirm Password Field
                Obx(() => CustomTextField(
                      controller: controller.confirmPasswordController,
                      hintText: "Confirm Password",
                      isPassword: !controller.isConfirmPasswordVisible.value,
                      suffixIcon: IconButton(
                        icon: Icon(
                          controller.isConfirmPasswordVisible.value
                              ? Icons.visibility
                              : Icons.visibility_off,
                          color: Colors.grey,
                        ),
                        onPressed: controller.toggleConfirmPasswordVisibility,
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return "Please confirm your password";
                        }
                        if (value != controller.passwordController.text) {
                          return "Passwords do not match";
                        }
                        return null;
                      },
                    )),
                const SizedBox(height: 32),

                // Reset Password Button
                CustomButton(
                  text: "Reset Password",
                  onPressed: (){
                    Get.to(()=> LoginPage());
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
