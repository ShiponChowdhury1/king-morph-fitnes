import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:demo_project/app/routes/app_routes.dart';

class OtpVerifyController extends GetxController {
  final List<TextEditingController> otpControllers = List.generate(6, (index) => TextEditingController());
  final List<FocusNode> focusNodes = List.generate(6, (index) => FocusNode());

  final RxInt timerSeconds = 49.obs;
  Timer? _timer;

  @override
  void onInit() {
    startTimer();
    super.onInit();
  }

  void startTimer() {
    timerSeconds.value = 49;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (timerSeconds.value > 0) {
        timerSeconds.value--;
      } else {
        _timer?.cancel();
      }
    });
  }

  void resendCode() {
    if (timerSeconds.value == 0) {
      startTimer();
      Get.snackbar("Success", "Verification code resent!");
    }
  }

  void verifyOtp() {
    String otp = otpControllers.map((e) => e.text).join();
    if (otp.length < 6) {
      Get.snackbar("Error", "Please enter the full 6-digit code");
      return;
    }
    // For Forget Password flow, navigate to Reset Password
    Get.toNamed(AppRoutes.resetPassword);
  }

  @override
  void onClose() {
    _timer?.cancel();
    for (var controller in otpControllers) {
      controller.dispose();
    }
    for (var node in focusNodes) {
      node.dispose();
    }
    super.onClose();
  }
}
