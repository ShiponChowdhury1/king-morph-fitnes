import 'package:demo_project/app/features/forget/controller/forget_controller.dart';
import 'package:demo_project/app/features/forget/controller/otp_verify_controller.dart';
import 'package:demo_project/app/features/forget/controller/reset_password_controller.dart';
import 'package:get/get.dart';

class ForgetBinding extends Bindings{
  @override
  void dependencies() {
    Get.lazyPut(() => ForgetController());
    Get.lazyPut(() => OtpVerifyController());
    Get.lazyPut(() => ResetPasswordController());
  }
}