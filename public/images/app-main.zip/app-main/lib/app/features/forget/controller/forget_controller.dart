import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:demo_project/app/routes/app_routes.dart';

class ForgetController extends GetxController {
  final emailController = TextEditingController();
  final formKey = GlobalKey<FormState>();

  void sendOtp() {
    if (formKey.currentState!.validate()) {
      // Logic to send OTP
      Get.toNamed(AppRoutes.otpVerification);
    }
  }

  @override
  void onClose() {
    emailController.dispose();
    super.onClose();
  }
}
