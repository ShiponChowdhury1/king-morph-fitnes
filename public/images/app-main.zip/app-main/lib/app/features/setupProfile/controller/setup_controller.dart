import 'package:get/get.dart';

class SetupController extends GetxController {
  /// null = no selection, 'male' or 'female'
  final selectedGender = RxnString();

  void selectGender(String gender) {
    selectedGender.value = gender;
  }

  bool get isMaleSelected => selectedGender.value == 'male';
  bool get isFemaleSelected => selectedGender.value == 'female';
  bool get hasSelection => selectedGender.value != null;

  // Step 2: Focus Areas
  final femaleFocusAreas = <String>[].obs;

  void toggleFemaleFocusArea(String area) {
    if (femaleFocusAreas.contains(area)) {
      femaleFocusAreas.remove(area);
    } else {
      femaleFocusAreas.add(area);
    }
  }

  // Step 3: Goal
  final femaleGoal = RxnString();

  void setFemaleGoal(String goal) {
    femaleGoal.value = goal;
  }

  // Step 4: Body Type
  final femaleBodyType = RxnString();

  void setFemaleBodyType(String bodyType) {
    femaleBodyType.value = bodyType;
  }

  // Step 5: Activity Level
  final femaleActivityLevel = RxnString();

  void setFemaleActivityLevel(String level) {
    femaleActivityLevel.value = level;
  }

  // Step 6: Weekly Training Days
  final femaleTrainingDays = RxnInt();
  final femaleFirstDayOfWeek = RxString('Sunday');

  void setFemaleTrainingDays(int days) {
    femaleTrainingDays.value = days;
  }

  void setFemaleFirstDayOfWeek(String day) {
    femaleFirstDayOfWeek.value = day;
  }

  // Step 7: Workout Location
  final femaleWorkoutLocation = RxnString();

  void setFemaleWorkoutLocation(String location) {
    femaleWorkoutLocation.value = location;
  }

  // Step 8: Age
  final femaleAge = RxInt(28);

  void setFemaleAge(int age) {
    femaleAge.value = age;
  }

  // Step 9: Weight & Height
  final femaleWeight = RxInt(75);
  final femaleWeightUnit = RxString('lbs'); // 'KG' or 'lbs'
  final femaleHeightFt = RxInt(5);
  final femaleHeightIn = RxInt(5);
  final femaleHeightCm = RxInt(165);
  final femaleHeightUnit = RxString('Ft'); // 'Cm' or 'Ft'

  void setFemaleWeight(int w) => femaleWeight.value = w;
  void setFemaleWeightUnit(String u) => femaleWeightUnit.value = u;
  void setFemaleHeightFt(int ft) => femaleHeightFt.value = ft;
  void setFemaleHeightIn(int inches) => femaleHeightIn.value = inches;
  void setFemaleHeightCm(int cm) => femaleHeightCm.value = cm;
  void setFemaleHeightUnit(String u) => femaleHeightUnit.value = u;
}
