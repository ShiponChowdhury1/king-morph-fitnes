import 'package:demo_project/app/features/setupProfile/view/MalePage/male_step_four.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:demo_project/app/features/setupProfile/controller/setup_male_controller.dart';
import 'package:demo_project/app/core/widgets/custom_button.dart';

class MaleStepThree extends StatelessWidget {
  const MaleStepThree({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(SetupMaleController());

    final List<String> goals = [
      'Lose Weight',
      'Build Muscle',
      'Get Toned',
      'Maintain',
    ];

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            // ── Top Bar ────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () => Get.back(),
                    child: const Icon(
                      Icons.arrow_back,
                      color: Color(0xFF0A0615),
                      size: 24,
                    ),
                  ),
                  const Text(
                    'Step 3 of 9',
                    style: TextStyle(
                      color: Color(0xFF0A0615),
                      fontSize: 16,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(width: 24), // Placeholder to balance the row
                ],
              ),
            ),

            const SizedBox(height: 32),

            // ── Title ──────────────────────────────────────────────────
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 24),
              child: Text(
                'What Is Your Goal?',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF0A0615),
                  fontSize: 27,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),

            const SizedBox(height: 32),

            // ── Goal List ──────────────────────────────────────────────
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                physics: const BouncingScrollPhysics(),
                itemCount: goals.length,
                separatorBuilder: (context, index) => const SizedBox(height: 16),
                itemBuilder: (context, index) {
                  final goal = goals[index];
                  return Obx(() {
                    final isSelected = controller.maleGoal.value == goal;

                    return GestureDetector(
                      onTap: () => controller.setMaleGoal(goal),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 20),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF8FAFC),
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(
                            color: isSelected
                                ? const Color(0xFF0A0615)
                                : Colors.transparent,
                            width: 1.5,
                          ),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              goal,
                              style: TextStyle(
                                color: const Color(0xFF232323),
                                fontSize: 16,
                                fontFamily: 'Poppins',
                                fontWeight: isSelected
                                    ? FontWeight.w500
                                    : FontWeight.w400,
                              ),
                            ),
                            Container(
                              width: 24,
                              height: 24,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: const Color(0xFF232323),
                                  width: 2,
                                ),
                              ),
                              child: isSelected
                                  ? Center(
                                      child: Container(
                                        width: 12,
                                        height: 12,
                                        decoration: const BoxDecoration(
                                          color: Color(0xFF0A0615),
                                          shape: BoxShape.circle,
                                        ),
                                      ),
                                    )
                                  : null,
                            ),
                          ],
                        ),
                      ),
                    );
                  });
                },
              ),
            ),

            // ── Next Button ────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.all(24),
              child: CustomButton(
                text: 'Next',
                onPressed: () {
                  Get.to(() => const MaleStepFour());
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}