import 'package:demo_project/app/core/widgets/custom_button.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:demo_project/app/features/setupProfile/controller/setup_male_controller.dart';
import 'package:demo_project/app/features/setupProfile/view/MalePage/male_step_three.dart';

class MaleStepTwo extends StatelessWidget {
  MaleStepTwo({super.key});

  final controller = Get.put(SetupMaleController());

  final List<Map<String, String>> areas = [
    {
      'id': 'full_body',
      'label': 'Full Body',
      'image': 'assets/images/m_fullbody.png',
    },
    {'id': 'arm', 'label': 'Arm', 'image': 'assets/images/m_arm.png'},
    {'id': 'abs', 'label': 'Abs', 'image': 'assets/images/m_abs.png'},
    {'id': 'back', 'label': 'Back', 'image': 'assets/images/m_back.png'},
    {'id': 'leg', 'label': 'Leg', 'image': 'assets/images/m_leg.png'},
    {'id': 'butts', 'label': 'Butts', 'image': 'assets/images/m_butts.png'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            // ── Top Bar ────────────────────────────────────────────────
            Padding(
               padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () => Get.back(),
                    child: const Icon(
                      Icons.arrow_back,
                      color: Color(0xFF0A0615),
                      size: 24,
                    ),
                  ),
                  const Text(
                    'Step 2 of 9',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 16,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(width: 24), // Placeholder to balance the row
                ],
              ),
            ),

            const SizedBox(height: 24),

            // ── Title ──────────────────────────────────────────────────
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 24),
              child: Text(
                'Choose your focus area',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF0A0615),
                  fontSize: 27,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),

            const SizedBox(height: 24),

            // ── Grid View ──────────────────────────────────────────────
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: GridView.builder(
                  physics: const BouncingScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 16,
                    crossAxisSpacing: 16,
                    childAspectRatio: 0.8,
                  ),
                  itemCount: areas.length,
                  itemBuilder: (context, index) {
                    final item = areas[index];
                    return _buildFocusCard(
                      id: item['id']!,
                      label: item['label']!,
                      imagePath: item['image']!,
                    );
                  },
                ),
              ),
            ),

            // ── Continue Button ────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.all(24),
              child: CustomButton(
                text: 'Continue',
                onPressed: () {
                  Get.to(() => const MaleStepThree());
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFocusCard({
    required String id,
    required String label,
    required String imagePath,
  }) {
    return GestureDetector(
      onTap: () => controller.toggleMaleFocusArea(id),
      child: Obx(() {
        final isSelected = controller.maleFocusAreas.contains(id);

        return Container(
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.1),
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Stack(
            fit: StackFit.expand,
            children: [
              // Background image
              Image.asset(imagePath, fit: BoxFit.cover),

              // Gradient for text readability
              Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        Colors.transparent,
                        Colors.black.withValues(alpha: 0.6),
                        Colors.black.withValues(alpha: 0.8),
                      ],
                      stops: const [0.0, 0.5, 0.8, 1.0],
                    ),
                  ),
                ),
              ),

              // Label text
              Positioned(
                left: 0,
                right: 0,
                bottom: 16,
                child: Center(
                  child: Text(
                    label,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),

              // Selection circle indicator
              Positioned(
                top: 12,
                right: 12,
                child: Container(
                  width: 30,
                  height: 30,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child: isSelected
                      ? const Icon(
                          Icons.check,
                          color: Color(0xFF34C759),
                          size: 20,
                        )
                      : null,
                ),
              ),
            ],
          ),
        );
      }),
    );
  }
}