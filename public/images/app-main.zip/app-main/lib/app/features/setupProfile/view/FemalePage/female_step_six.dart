import 'package:demo_project/app/features/setupProfile/view/FemalePage/female_step_seven.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:demo_project/app/features/setupProfile/controller/setup_controller.dart';
import 'package:demo_project/app/core/widgets/custom_button.dart';

class FemaleStepSix extends StatelessWidget {
  const FemaleStepSix({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<SetupController>();

    final List<String> daysOfWeek = [
      'Sunday',
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
    ];

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            // ── Top Bar ────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () => Get.back(),
                    child: const Icon(
                      Icons.arrow_back,
                      color: Color(0xFF0A0615),
                      size: 24,
                    ),
                  ),
                  const Text(
                    'Step 6 of 9',
                    style: TextStyle(
                      color: Color(0xFF0A0615),
                      fontSize: 16,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(width: 24),
                ],
              ),
            ),

            const SizedBox(height: 32),

            // ── Title ──────────────────────────────────────────────────
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 24),
              child: Text(
                'Weekly training days',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF0A0615),
                  fontSize: 27,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),

            const SizedBox(height: 32),

            // ── Day Number Grid ────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Obx(() {
                return Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  alignment: WrapAlignment.center,
                  children: List.generate(7, (index) {
                    final dayNumber = index + 1;
                    final isSelected =
                        controller.femaleTrainingDays.value == dayNumber;

                    return GestureDetector(
                      onTap: () => controller.setFemaleTrainingDays(dayNumber),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          color: isSelected
                              ? const Color(0xFF0A0615)
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: const Color(0xFFE5E9EF),
                            width: 1.5,
                          ),
                        ),
                        child: Center(
                          child: Text(
                            '$dayNumber',
                            style: TextStyle(
                              color: isSelected
                                  ? Colors.white
                                  : const Color(0xFF0A0615),
                              fontSize: 20,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
                );
              }),
            ),

            const SizedBox(height: 48),

            // ── First Day of Week Label ────────────────────────────────
            const Text(
              'First day of week',
              style: TextStyle(
                color: Color(0xFF000000),
                fontSize: 16,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w500,
              ),
            ),

            const SizedBox(height: 12),

            // ── Dropdown ───────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30),
              child: Obx(() {
                return Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF8FAFC),
                    borderRadius: BorderRadius.circular(36),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: controller.femaleFirstDayOfWeek.value,
                      isExpanded: true,
                      icon: const Icon(
                        Icons.keyboard_arrow_down_rounded,
                        color: Color(0xFF343330),
                        size: 28,
                      ),
                      dropdownColor: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      style: const TextStyle(
                        color: Color(0xFF232323),
                        fontSize: 22,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                      ),
                      items: daysOfWeek.map((day) {
                        return DropdownMenuItem<String>(
                          value: day,
                          child: Text(day),
                        );
                      }).toList(),
                      onChanged: (value) {
                        if (value != null) {
                          controller.setFemaleFirstDayOfWeek(value);
                        }
                      },
                    ),
                  ),
                );
              }),
            ),

            const Spacer(),

            // ── Next Button ────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.all(24),
              child: CustomButton(
                text: 'Next',
                onPressed: () {
                  // Navigate to Step 7
                  Get.to(()=> FemaleStepSeven());
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
