import 'package:get/get.dart';

class SetupMaleController extends GetxController {

  // Step 2: Focus Area
  final maleFocusAreas = <String>[].obs;

  void toggleMaleFocusArea(String area) {
    if (maleFocusAreas.contains(area)) {
      maleFocusAreas.remove(area);
    } else {
      maleFocusAreas.add(area);
    }
  }

  // Step 3: Goal
  final maleGoal = RxnString();

  void setMaleGoal(String goal) {
    maleGoal.value = goal;
  }

  // Step 4: Body Type
  final maleBodyType = RxnString();

  void setMaleBodyType(String type) {
    maleBodyType.value = type;
  }

  // Step 5: Activity Level
  final maleActivityLevel = RxnString();

  void setMaleActivityLevel(String level) {
    maleActivityLevel.value = level;
  }

  // Step 6: Weekly Training Days
  final maleTrainingDays = RxnInt();
  final maleFirstDayOfWeek = RxString('Sunday');

  void setMaleTrainingDays(int days) {
    maleTrainingDays.value = days;
  }

  void setMaleFirstDayOfWeek(String day) {
    maleFirstDayOfWeek.value = day;
  }

  // Step 7: Workout Location
  final maleWorkoutLocation = RxnString();

  void setMaleWorkoutLocation(String location) {
    maleWorkoutLocation.value = location;
  }

  // Step 8: Age
  final maleAge = RxInt(28);

  void setMaleAge(int age) {
    maleAge.value = age;
  }

  // Step 9: Weight & Height
  final maleWeight = RxInt(75);
  final maleWeightUnit = RxString('lbs'); // 'KG' or 'lbs'
  final maleHeightFt = RxInt(5);
  final maleHeightIn = RxInt(5);
  final maleHeightCm = RxInt(165);
  final maleHeightUnit = RxString('Ft'); // 'Cm' or 'Ft'

  void setMaleWeight(int w) => maleWeight.value = w;
  void setMaleWeightUnit(String u) => maleWeightUnit.value = u;
  void setMaleHeightFt(int ft) => maleHeightFt.value = ft;
  void setMaleHeightIn(int inches) => maleHeightIn.value = inches;
  void setMaleHeightCm(int cm) => maleHeightCm.value = cm;
  void setMaleHeightUnit(String u) => maleHeightUnit.value = u;
}