import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:demo_project/app/features/setupProfile/controller/setup_controller.dart';
import 'package:demo_project/app/core/widgets/custom_button.dart';
import 'package:demo_project/app/features/setupProfile/view/FemalePage/female_animation_page.dart';

class FemaleStepNine extends StatefulWidget {
  const FemaleStepNine({super.key});

  @override
  State<FemaleStepNine> createState() => _FemaleStepNineState();
}

class _FemaleStepNineState extends State<FemaleStepNine> {
  late final SetupController controller;
  late final FixedExtentScrollController _weightScrollController;
  late final FixedExtentScrollController _heightScrollController;

  static const int _minWeightLbs = 50;
  static const int _maxWeightLbs = 400;
  static const int _minWeightKg = 20;
  static const int _maxWeightKg = 180;

  // Height in Ft mode: combined ft*12+in
  static const int _minHeightFt = 3;
  static const int _maxHeightFt = 7;
  // Total items for Ft: (maxFt - minFt) * 12 + 12
  static const int _minHeightCm = 100;
  static const int _maxHeightCm = 220;

  static const double _itemWidth = 70.0;

  @override
  void initState() {
    super.initState();
    controller = Get.find<SetupController>();
    _weightScrollController = FixedExtentScrollController(
      initialItem: controller.femaleWeight.value - _minWeightLbs,
    );
    // Height initial: 5ft 5in = index (5-3)*12 + 5 = 29
    _heightScrollController = FixedExtentScrollController(
      initialItem: (controller.femaleHeightFt.value - _minHeightFt) * 12 +
          controller.femaleHeightIn.value,
    );
  }

  @override
  void dispose() {
    _weightScrollController.dispose();
    _heightScrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            // ── Top Bar ────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () => Get.back(),
                    child: const Icon(
                      Icons.arrow_back,
                      color: Color(0xFF0A0615),
                      size: 24,
                    ),
                  ),
                  const Text(
                    'Step 9 of 9',
                    style: TextStyle(
                      color: Color(0xFF0A0615),
                      fontSize: 16,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(width: 24),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // ── Title ──────────────────────────────────────────────────
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 24),
              child: Text(
                'Tell us about yourself',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF0A0615),
                  fontSize: 27,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),

            const SizedBox(height: 24),

            // ── Weight Section ─────────────────────────────────────────
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(
                  children: [
                    // Weight header with unit toggle
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Weight',
                            style: TextStyle(
                              color: Color(0xFF0A0615),
                              fontSize: 18,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Obx(() => _buildUnitToggle(
                                units: ['KG', 'lbs'],
                                selectedUnit:
                                    controller.femaleWeightUnit.value,
                                onChanged: (unit) {
                                  controller.setFemaleWeightUnit(unit);
                                  // Reset scroll position
                                  final newInitial = unit == 'KG'
                                      ? controller.femaleWeight.value -
                                          _minWeightKg
                                      : controller.femaleWeight.value -
                                          _minWeightLbs;
                                  _weightScrollController.jumpToItem(
                                    newInitial.clamp(
                                      0,
                                      unit == 'KG'
                                          ? _maxWeightKg - _minWeightKg
                                          : _maxWeightLbs - _minWeightLbs,
                                    ),
                                  );
                                },
                              )),
                        ],
                      ),
                    ),

                    const SizedBox(height: 12),

                    // Weight horizontal picker
                    SizedBox(
                      height: 70,
                      child: Obx(() {
                        final isKg =
                            controller.femaleWeightUnit.value == 'KG';
                        final minW = isKg ? _minWeightKg : _minWeightLbs;
                        final maxW = isKg ? _maxWeightKg : _maxWeightLbs;
                        final unitLabel = isKg ? 'kg' : 'lbs';

                        return RotatedBox(
                          quarterTurns: -1,
                          child: ListWheelScrollView.useDelegate(
                            controller: _weightScrollController,
                            itemExtent: _itemWidth,
                            perspective: 0.002,
                            physics: const FixedExtentScrollPhysics(),
                            onSelectedItemChanged: (index) {
                              controller.setFemaleWeight(minW + index);
                            },
                            childDelegate: ListWheelChildBuilderDelegate(
                              childCount: maxW - minW + 1,
                              builder: (context, index) {
                                final w = minW + index;
                                return RotatedBox(
                                  quarterTurns: 1,
                                  child: Obx(() {
                                    final isSelected =
                                        controller.femaleWeight.value == w;
                                    return SizedBox(
                                      width: _itemWidth,
                                      child: Center(
                                        child: isSelected
                                            ? OverflowBox(
                                                maxWidth: 200,
                                                child: RichText(
                                                  softWrap: false,
                                                  overflow: TextOverflow.visible,
                                                  text: TextSpan(
                                                    children: [
                                                      TextSpan(
                                                        text: '$w',
                                                        style: const TextStyle(
                                                          color:
                                                              Color(0xFF0A0615),
                                                          fontSize: 36,
                                                          fontFamily: 'Poppins',
                                                          fontWeight:
                                                              FontWeight.w700,
                                                        ),
                                                      ),
                                                      TextSpan(
                                                        text: unitLabel,
                                                        style: const TextStyle(
                                                          color:
                                                              Color(0xFF0A0615),
                                                          fontSize: 16,
                                                          fontFamily: 'Poppins',
                                                          fontWeight:
                                                              FontWeight.w400,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              )
                                            : Text(
                                                '$w',
                                                style: const TextStyle(
                                                  color: Color(0xFF9E9E9E),
                                                  fontSize: 24,
                                                  fontFamily: 'Poppins',
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                      ),
                                    );
                                  }),
                                );
                              },
                            ),
                          ),
                        );
                      }),
                    ),

                    // Weight ruler tick marks
                    _buildRuler(),

                    const SizedBox(height: 32),

                    // Height header with unit toggle
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Height',
                            style: TextStyle(
                              color: Color(0xFF0A0615),
                              fontSize: 18,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Obx(() => _buildUnitToggle(
                                units: ['Cm', 'Ft'],
                                selectedUnit:
                                    controller.femaleHeightUnit.value,
                                onChanged: (unit) {
                                  controller.setFemaleHeightUnit(unit);
                                  if (unit == 'Cm') {
                                    _heightScrollController.jumpToItem(
                                      (controller.femaleHeightCm.value -
                                              _minHeightCm)
                                          .clamp(
                                              0, _maxHeightCm - _minHeightCm),
                                    );
                                  } else {
                                    _heightScrollController.jumpToItem(
                                      ((controller.femaleHeightFt.value -
                                                  _minHeightFt) *
                                              12 +
                                          controller.femaleHeightIn.value),
                                    );
                                  }
                                },
                              )),
                        ],
                      ),
                    ),

                    const SizedBox(height: 12),

                    // Height horizontal picker
                    SizedBox(
                      height: 70,
                      child: Obx(() {
                        final isFt =
                            controller.femaleHeightUnit.value == 'Ft';

                        if (isFt) {
                          // Ft + In mode
                          final totalItems =
                              (_maxHeightFt - _minHeightFt + 1) * 12;
                          return RotatedBox(
                            quarterTurns: -1,
                            child: ListWheelScrollView.useDelegate(
                              controller: _heightScrollController,
                              itemExtent: _itemWidth,
                              perspective: 0.002,
                              physics: const FixedExtentScrollPhysics(),
                              onSelectedItemChanged: (index) {
                                final ft =
                                    _minHeightFt + (index ~/ 12);
                                final inch = index % 12;
                                controller.setFemaleHeightFt(ft);
                                controller.setFemaleHeightIn(inch);
                              },
                              childDelegate:
                                  ListWheelChildBuilderDelegate(
                                childCount: totalItems,
                                builder: (context, index) {
                                  final ft =
                                      _minHeightFt + (index ~/ 12);
                                  final inch = index % 12;
                                  return RotatedBox(
                                    quarterTurns: 1,
                                    child: Obx(() {
                                      final isSelected = controller
                                                  .femaleHeightFt.value ==
                                              ft &&
                                          controller
                                                  .femaleHeightIn.value ==
                                              inch;
                                      return SizedBox(
                                        width: _itemWidth,
                                        child: Center(
                                          child: isSelected
                                              ? OverflowBox(
                                                  maxWidth: 200,
                                                  child: RichText(
                                                    softWrap: false,
                                                    overflow: TextOverflow.visible,
                                                    text: TextSpan(
                                                      children: [
                                                        TextSpan(
                                                          text: '$ft',
                                                          style:
                                                              const TextStyle(
                                                            color: Color(
                                                                0xFF0A0615),
                                                            fontSize: 36,
                                                            fontFamily:
                                                                'Poppins',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w700,
                                                          ),
                                                        ),
                                                        const TextSpan(
                                                          text: 'ft ',
                                                          style: TextStyle(
                                                            color: Color(
                                                                0xFF0A0615),
                                                            fontSize: 16,
                                                            fontFamily:
                                                                'Poppins',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w400,
                                                          ),
                                                        ),
                                                        TextSpan(
                                                          text: '$inch',
                                                          style:
                                                              const TextStyle(
                                                            color: Color(
                                                                0xFF0A0615),
                                                            fontSize: 36,
                                                            fontFamily:
                                                                'Poppins',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w700,
                                                          ),
                                                        ),
                                                        const TextSpan(
                                                          text: 'in',
                                                          style: TextStyle(
                                                            color: Color(
                                                                0xFF0A0615),
                                                            fontSize: 16,
                                                            fontFamily:
                                                                'Poppins',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w400,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                )
                                              : Text(
                                                  '$ft',
                                                  style: const TextStyle(
                                                    color:
                                                        Color(0xFF9E9E9E),
                                                    fontSize: 24,
                                                    fontFamily: 'Poppins',
                                                    fontWeight:
                                                        FontWeight.w500,
                                                  ),
                                                ),
                                        ),
                                      );
                                    }),
                                  );
                                },
                              ),
                            ),
                          );
                        } else {
                          // Cm mode
                          return RotatedBox(
                            quarterTurns: -1,
                            child: ListWheelScrollView.useDelegate(
                              controller: _heightScrollController,
                              itemExtent: _itemWidth,
                              perspective: 0.002,
                              physics: const FixedExtentScrollPhysics(),
                              onSelectedItemChanged: (index) {
                                controller
                                    .setFemaleHeightCm(_minHeightCm + index);
                              },
                              childDelegate:
                                  ListWheelChildBuilderDelegate(
                                childCount:
                                    _maxHeightCm - _minHeightCm + 1,
                                builder: (context, index) {
                                  final cm = _minHeightCm + index;
                                  return RotatedBox(
                                    quarterTurns: 1,
                                    child: Obx(() {
                                      final isSelected =
                                          controller.femaleHeightCm.value ==
                                              cm;
                                      return SizedBox(
                                        width: _itemWidth,
                                        child: Center(
                                          child: isSelected
                                              ? OverflowBox(
                                                  maxWidth: 200,
                                                  child: RichText(
                                                    softWrap: false,
                                                    overflow: TextOverflow.visible,
                                                    text: TextSpan(
                                                      children: [
                                                        TextSpan(
                                                          text: '$cm',
                                                          style:
                                                              const TextStyle(
                                                            color: Color(
                                                                0xFF0A0615),
                                                            fontSize: 36,
                                                            fontFamily:
                                                                'Poppins',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w700,
                                                          ),
                                                        ),
                                                        const TextSpan(
                                                          text: 'cm',
                                                          style: TextStyle(
                                                            color: Color(
                                                                0xFF0A0615),
                                                            fontSize: 16,
                                                            fontFamily:
                                                                'Poppins',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w400,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                )
                                              : Text(
                                                  '$cm',
                                                  style: const TextStyle(
                                                    color:
                                                        Color(0xFF9E9E9E),
                                                    fontSize: 24,
                                                    fontFamily: 'Poppins',
                                                    fontWeight:
                                                        FontWeight.w500,
                                                  ),
                                                ),
                                        ),
                                      );
                                    }),
                                  );
                                },
                              ),
                            ),
                          );
                        }
                      }),
                    ),

                    // Height ruler tick marks
                    _buildRuler(),

                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ),

            // ── Get my plans Button ────────────────────────────────────
            Padding(
              padding: const EdgeInsets.all(24),
              child: CustomButton(
                text: 'Get my plans',
                onPressed: () {
                  Get.to(() => const FemaleAnimationPage());
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Unit Toggle Widget ──────────────────────────────────────────────
  Widget _buildUnitToggle({
    required List<String> units,
    required String selectedUnit,
    required ValueChanged<String> onChanged,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: const Color(0xFFF1F3F5),
      ),
      padding: const EdgeInsets.all(3),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: units.map((unit) {
          final isActive = selectedUnit == unit;
          return GestureDetector(
            onTap: () => onChanged(unit),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: isActive ? const Color(0xFF0A0615) : Colors.transparent,
                borderRadius: BorderRadius.circular(18),
              ),
              child: Text(
                unit,
                style: TextStyle(
                  color: isActive ? Colors.white : const Color(0xFF6B7280),
                  fontSize: 14,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  // ── Ruler Tick Marks ────────────────────────────────────────────────
  Widget _buildRuler() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: SizedBox(
        height: 30,
        child: CustomPaint(
          size: Size(MediaQuery.of(context).size.width - 32, 30),
          painter: _RulerPainter(),
        ),
      ),
    );
  }
}

/// Draws a horizontal ruler with tick marks, thicker at the center
class _RulerPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFD1D5DB)
      ..strokeWidth = 1.2;

    final centerX = size.width / 2;
    final centerPaint = Paint()
      ..color = const Color(0xFFE8B931) // Yellow center line
      ..strokeWidth = 2.5;

    const tickSpacing = 8.0;
    final tickCount = (size.width / tickSpacing).floor();

    for (int i = 0; i <= tickCount; i++) {
      final x = i * tickSpacing;
      final isMajor = i % 5 == 0;
      final tickHeight = isMajor ? 20.0 : 12.0;
      final y = size.height - tickHeight;

      // Check if this is close to center
      if ((x - centerX).abs() < tickSpacing / 2) {
        canvas.drawLine(
          Offset(x, 0),
          Offset(x, size.height),
          centerPaint,
        );
      } else {
        canvas.drawLine(
          Offset(x, y),
          Offset(x, size.height),
          paint,
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
