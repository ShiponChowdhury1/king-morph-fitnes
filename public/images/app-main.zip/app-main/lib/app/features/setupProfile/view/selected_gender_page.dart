import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:demo_project/app/features/setupProfile/controller/setup_controller.dart';
import 'package:demo_project/app/routes/app_routes.dart';

class SelectedGenderPage extends StatelessWidget {
  SelectedGenderPage({super.key});

  final controller = Get.find<SetupController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: SizedBox.expand(
          child: _buildSideBySideView(),
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Back button
          GestureDetector(
            onTap: () => Get.back(),
            child: const Icon(
              Icons.arrow_back,
              color: Colors.white,
              size: 20,
            ),
          ),

          // Step indicator
          Text(
            'Step 1 of 9',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w500,
            ),
          ),

          // Skip button
          GestureDetector(
            onTap: () {
              // Skip action
            },
            child: const Text(
              'Skip',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w400,
              ),
            ),
          ),
        ],
      ),
    );
  }



  // ═══════════════════════════════════════════════════════════════════════════
  // Side-by-side (initial) view — full-screen Stack layout
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildSideBySideView() {
    return Stack(
      children: [
        // ── Full-screen image cards ────────────────────────────────
        Positioned.fill(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            child: Row(
              children: [
                // Male card
                Expanded(
                  child: _buildGenderCard(
                    gender: 'male',
                    label: 'Male',
                    imagePath: 'assets/images/male.png',
                  ),
                ),
                const SizedBox(width: 12),
                // Female card
                Expanded(
                  child: _buildGenderCard(
                    gender: 'female',
                    label: 'Female',
                    imagePath: 'assets/images/female.png',
                  ),
                ),
              ],
            ),
          ),
        ),

        // ── Top bar overlay ────────────────────────────────────────
        _buildTopBar(),

        // ── "Choose gender" title overlay ──────────────────────────
        Positioned(
          top: 56,
          left: 0,
          right: 0,
          child: Center(
            child: Text(
              'Choose gender',
              style: TextStyle(
                color: Colors.white,
                fontSize: 27,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w600,
                shadows: [
                  Shadow(
                    color: Colors.black.withValues(alpha: 0.6),
                    blurRadius: 12,
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildGenderCard({
    required String gender,
    required String label,
    required String imagePath,
  }) {
    return GestureDetector(
      onTap: () {
        controller.selectGender(gender);
        if (gender == 'male') {
          Get.toNamed(AppRoutes.malePage);
        } else {
          Get.toNamed(AppRoutes.femalePage);
        }
      },
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.3),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Background image
            Image.asset(
              imagePath,
              fit: BoxFit.cover,
            ),

            // Dark gradient overlay from bottom
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.transparent,
                      Colors.black.withValues(alpha: 0.7),
                      Colors.black.withValues(alpha: 0.9),
                    ],
                    stops: const [0.0, 0.4, 0.75, 1.0],
                  ),
                ),
              ),
            ),

            // Label at bottom — center-aligned
            Positioned(
              left: 0,
              right: 0,
              bottom: 20,
              child: Center(
                child: Text(
                  label,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 27,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                    shadows: [
                      Shadow(
                        color: Colors.black.withValues(alpha: 0.6),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }


}
