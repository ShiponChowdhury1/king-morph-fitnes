import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:demo_project/app/features/setupProfile/view/MalePage/male_start_training.dart';

class MaleAnimationPage extends StatefulWidget {
  const MaleAnimationPage({super.key});

  @override
  State<MaleAnimationPage> createState() => _MaleAnimationPageState();
}

class _MaleAnimationPageState extends State<MaleAnimationPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _animController;
  late final Animation<double> _progressAnimation;

  bool _isComplete = false;

  // Dynamic status messages that change as progress increases
  final List<_StatusMessage> _statusMessages = [
    _StatusMessage(0.0, 'Analyzing your data'),
    _StatusMessage(0.20, 'Fitness Level workout: Beginner'),
    _StatusMessage(0.40, 'Setting up workout: Full Body'),
    _StatusMessage(0.60, 'Personalizing your plan'),
    _StatusMessage(0.80, 'Finalizing recommendations'),
  ];

  @override
  void initState() {
    super.initState();

    _animController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    );

    _progressAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animController, curve: Curves.easeInOut),
    );

    _animController.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        setState(() {
          _isComplete = true;
        });
        // Navigate to next page after a brief pause
        Future.delayed(const Duration(milliseconds: 1500), () {
          if (mounted) {
            Get.off(() => const MaleStartTraining());
          }
        });
      }
    });

    // Start animation after a brief delay
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) {
        _animController.forward();
      }
    });
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  String _getCurrentStatus(double progress) {
    String status = _statusMessages.first.text;
    for (final msg in _statusMessages) {
      if (progress >= msg.threshold) {
        status = msg.text;
      }
    }
    return status;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: AnimatedBuilder(
            animation: _progressAnimation,
            builder: (context, child) {
              final progress = _progressAnimation.value;
              final percent = (progress * 100).toInt();
              final statusText = _isComplete
                  ? 'Data analyzation complete'
                  : _getCurrentStatus(progress);

              return Column(
                children: [
                  const SizedBox(height: 80),

                  // ── Title ────────────────────────────────────────────
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 400),
                    child: Text(
                      _isComplete
                          ? 'Personalized fitness plan\njust for you!'
                          : 'Generating personalized\nfitness plan just for you',
                      key: ValueKey<bool>(_isComplete),
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Color(0xFF0A0615),
                        fontSize: 26,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                        height: 1.3,
                      ),
                    ),
                  ),

                  const Spacer(),

                  // ── Circular Progress ────────────────────────────────
                  SizedBox(
                    width: 200,
                    height: 200,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        // Background circle
                        SizedBox(
                          width: 200,
                          height: 200,
                          child: CircularProgressIndicator(
                            value: 1.0,
                            strokeWidth: 12,
                            strokeCap: StrokeCap.round,
                            backgroundColor: const Color(0xFFF1F3F5),
                            valueColor: const AlwaysStoppedAnimation<Color>(
                              Color(0xFFF1F3F5),
                            ),
                          ),
                        ),
                        // Progress circle
                        SizedBox(
                          width: 200,
                          height: 200,
                          child: CircularProgressIndicator(
                            value: progress,
                            strokeWidth: 12,
                            strokeCap: StrokeCap.round,
                            backgroundColor: Colors.transparent,
                            valueColor: const AlwaysStoppedAnimation<Color>(
                              Color(0xFF000000),
                            ),
                          ),
                        ),
                        // Percentage text
                        Text(
                          '$percent%',
                          style: const TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 41,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 40),

                  // ── Status Text ──────────────────────────────────────
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    child: Text(
                      _isComplete
                          ? 'Data analyzation complete'
                          : 'Analyzing your data',
                      key: ValueKey<String>(
                        _isComplete ? 'complete' : 'analyzing',
                      ),
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Color(0xFF000000),
                        fontSize: 16,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ),

                  const SizedBox(height: 12),

                  // ── Detail Status Text ───────────────────────────────
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    child: _isComplete
                        ? const SizedBox.shrink()
                        : Text(
                            statusText,
                            key: ValueKey<String>(statusText),
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Color(0xFF6B7280),
                              fontSize: 14,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                  ),

                  const Spacer(flex: 2),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class _StatusMessage {
  final double threshold;
  final String text;

  _StatusMessage(this.threshold, this.text);
}