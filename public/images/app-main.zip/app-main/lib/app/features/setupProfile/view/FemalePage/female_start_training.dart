import 'package:flutter/material.dart';
import 'package:demo_project/app/core/widgets/custom_button.dart';

class FemaleStartTraining extends StatelessWidget {
  const FemaleStartTraining({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            children: [
              const SizedBox(height: 90),

              // ── Main Title ──────────────────────────────────────────────
              const Text(
                'Generated personalized\nfitness plan just for you',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF0A0615),
                  fontSize: 26,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w600,
                  height: 1.2,
                ),
              ),

              const SizedBox(height: 16),

              // ── Subtitle ───────────────────────────────────────────────
              const Text(
                'This personalized plan is perfect for you',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF000000),
                  fontSize: 16,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w400,
                ),
              ),

              const SizedBox(height: 60), // Extra space for overlapping image
              // ── Challenge Card ─────────────────────────────────────────
              Stack(
                clipBehavior: Clip.none,
                children: [
                  // Black background card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.only(
                      left: 155, // Adjusted space
                      top: 32,
                      bottom: 32,
                      right: 16,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFF000000),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          '30 Days',
                          style: TextStyle(
                            color: Color(0xFFFFFFFF),
                            fontSize: 17,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        const SizedBox(height: 4),
                        const Text(
                          'Full Body\nChallenge',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 25,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w700,
                            height: 1.2,
                          ),
                        ),
                        const SizedBox(height: 4),
                        const Text(
                          'Start your fitness\njourney today',
                          style: TextStyle(
                            color: Color(0xFFFFFFFF),
                            fontSize: 14,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Overlapping female image
                  Positioned(
                    left: 0,
                    bottom: 0,
                    child: Image.asset(
                      'assets/images/demo_female.png',
                      height: 250, 
                      fit: BoxFit.contain,
                    ),
                  ),
                ],
              ),

              const Spacer(),

              // ── Bottom Action Buttons ──────────────────────────────────
              CustomButton(
                text: 'Start Training',
                onPressed: () {
                  // Navigate to actual training or home
                },
              ),
              const SizedBox(height: 16),

              GestureDetector(
                onTap: () {
                  // Navigate to home page
                },
                child: const Text(
                  'Go to homepage',
                  style: TextStyle(
                    color: Color(0xFF6B7280),
                    fontSize: 14,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ),

              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}
