import 'package:demo_project/app/features/setupProfile/view/FemalePage/female_step_five.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:demo_project/app/features/setupProfile/controller/setup_controller.dart';
import 'package:demo_project/app/core/widgets/custom_button.dart';

class FemaleStepFour extends StatelessWidget {
  const FemaleStepFour({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<SetupController>();

    final List<Map<String, String>> bodyTypes = [
      {'id': 'a', 'image': 'assets/images/a.png'},
      {'id': 'h', 'image': 'assets/images/h.png'},
      {'id': 'x', 'image': 'assets/images/x.png'},
      {'id': 'o', 'image': 'assets/images/o.png'},
      {'id': 'v', 'image': 'assets/images/v.png'},
    ];

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            // ── Top Bar ────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () => Get.back(),
                    child: const Icon(
                      Icons.arrow_back,
                      color: Color(0xFF0A0615),
                      size: 24,
                    ),
                  ),
                  const Text(
                    'Step 4 of 9',
                    style: TextStyle(
                      color: Color(0xFF0A0615),
                      fontSize: 16,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(width: 24), // Placeholder to balance the row
                ],
              ),
            ),

            const SizedBox(height: 32),

            // ── Title ──────────────────────────────────────────────────
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 24),
              child: Text(
                'What Is Your body type?',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF0A0615),
                  fontSize: 27,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),

            const SizedBox(height: 30),

            // ── Horizontal Body Type List ──────────────────────────────
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                itemCount: bodyTypes.length,
                separatorBuilder: (context, index) => const SizedBox(width: 16),
                itemBuilder: (context, index) {
                  final bodyType = bodyTypes[index];
                  return Obx(() {
                    final isSelected =
                        controller.femaleBodyType.value == bodyType['id'];

                    return GestureDetector(
                      onTap: () =>
                          controller.setFemaleBodyType(bodyType['id']!),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        width: 140, // Fixed width for each body type card
                        decoration: BoxDecoration(
                          color: isSelected
                              ? const Color(0xFFF7F8F9)
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: isSelected
                                ? const Color(0xFF0A0615)
                                : Colors.transparent,
                            width: 2,
                          ),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Image.asset(
                                  bodyType['image']!,
                                  fit: BoxFit.contain,
                                ),
                              ),
                            ),
                   
                       
                            const SizedBox(height: 16),
                          ],
                        ),
                      ),
                    );
                  });
                },
              ),
            ),

            const SizedBox(height: 24),

            // ── Continue Button ────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.all(24),
              child: CustomButton(
                text: 'Continue',
                onPressed: () {
                  Get.to(()=> const FemaleStepFive());
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
