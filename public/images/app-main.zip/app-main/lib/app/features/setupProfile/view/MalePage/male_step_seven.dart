import 'package:demo_project/app/features/setupProfile/view/MalePage/male_step_eight.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:demo_project/app/features/setupProfile/controller/setup_male_controller.dart';
import 'package:demo_project/app/core/widgets/custom_button.dart';

class MaleStepSeven extends StatelessWidget {
  const MaleStepSeven({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(SetupMaleController());

    final List<String> locations = ['Home', 'GYM'];

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            // ── Top Bar ────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () => Get.back(),
                    child: const Icon(
                      Icons.arrow_back,
                      color: Color(0xFF0A0615),
                      size: 24,
                    ),
                  ),
                  const Text(
                    'Step 7 of 9',
                    style: TextStyle(
                      color: Color(0xFF0A0615),
                      fontSize: 16,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(width: 24), // Placeholder to balance the row
                ],
              ),
            ),

            const SizedBox(height: 32),

            // ── Title ──────────────────────────────────────────────────
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 24),
              child: Text(
                'Where do you workout?',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF0A0615),
                  fontSize: 27,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),

            const SizedBox(height: 32),

            // ── Locations List ─────────────────────────────────────────
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                physics: const BouncingScrollPhysics(),
                itemCount: locations.length,
                separatorBuilder: (context, index) =>
                    const SizedBox(height: 16),
                itemBuilder: (context, index) {
                  final location = locations[index];
                  return Obx(() {
                    final isSelected =
                        controller.maleWorkoutLocation.value == location;

                    return GestureDetector(
                      onTap: () => controller.setMaleWorkoutLocation(location),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        padding: const EdgeInsets.symmetric(vertical: 20),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF8FAFC),
                          borderRadius: BorderRadius.circular(
                            100,
                          ), // Pill shape
                          border: Border.all(
                            color: isSelected
                                ? const Color(0xFF0A0615)
                                : Colors.transparent,
                            width: 2,
                          ),
                        ),
                        child: Center(
                          child: Text(
                            location,
                            style: TextStyle(
                              color: const Color(0xFF232323),
                              fontSize: 18,
                              fontFamily: 'Poppins',
                              fontWeight: isSelected
                                  ? FontWeight.w600
                                  : FontWeight.w500,
                            ),
                          ),
                        ),
                      ),
                    );
                  });
                },
              ),
            ),

            // ── Next Button ────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.all(24),
              child: CustomButton(
                text: 'Next',
                onPressed: () {
                  Get.to(() => const MaleStepEight());
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
