import 'package:flutter/material.dart';
import 'package:demo_project/app/core/widgets/custom_button.dart';

class MaleStartTraining extends StatelessWidget {
  const MaleStartTraining({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            children: [
              const SizedBox(height: 90),

              // ── Main Title ──────────────────────────────────────────────
              const Text(
                'Generated personalized\nfitness plan just for you',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF0A0615),
                  fontSize: 26,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w600,
                  height: 1.2,
                ),
              ),

              const SizedBox(height: 16),

              // ── Subtitle ───────────────────────────────────────────────
              const Text(
                'This personalized plan is perfect for you',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF000000),
                  fontSize: 16,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w400,
                ),
              ),

              const SizedBox(height: 24),
              // ── Challenge Card ─────────────────────────────────────────
              Stack(
                clipBehavior: Clip.none,
                children: [
                  // Blue gradient card
                  Container(
                    width: double.infinity,
                    height: 220,
                    padding: const EdgeInsets.only(
                      left: 185,
                      top: 32,
                      bottom: 32,
                      right: 16,
                    ),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [
                          Color(0xFF3B82F6), // Blue
                          Color(0xFF2563EB), // Deeper blue
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          '30 Days',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        const SizedBox(height: 4),
                        const Text(
                          'Full Body\nChallenge',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w700,
                            height: 1.2,
                          ),
                        ),
                        const SizedBox(height: 4),
                        const Text(
                          'Start your fitness\njourney today',
                          style: TextStyle(
                            color: Color(0xDDFFFFFF),
                            fontSize: 13,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Male image overflowing on the left
                  Positioned(
                    left: -15,
                    bottom: 0,
                    child: Image.asset(
                      'assets/images/demo_male.png',
                      height: 250,
                      fit: BoxFit.contain,
                    ),
                  ),
                ],
              ),

              const Spacer(),

              // ── Bottom Action Buttons ──────────────────────────────────
              CustomButton(
                text: 'Start Training',
                onPressed: () {
                  // Navigate to actual training or home
                },
              ),
              const SizedBox(height: 16),

              GestureDetector(
                onTap: () {
                  // Navigate to home page
                },
                child: const Text(
                  'Go to homepage',
                  style: TextStyle(
                    color: Color(0xFF6B7280),
                    fontSize: 14,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ),

              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}