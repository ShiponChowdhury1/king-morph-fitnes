import 'package:demo_project/app/features/setupProfile/view/MalePage/male_step_nine.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:demo_project/app/features/setupProfile/controller/setup_male_controller.dart';
import 'package:demo_project/app/core/widgets/custom_button.dart';

class MaleStepEight extends StatefulWidget {
  const MaleStepEight({super.key});

  @override
  State<MaleStepEight> createState() => _MaleStepEightState();
}

class _MaleStepEightState extends State<MaleStepEight> {
  late final SetupMaleController controller;
  late final FixedExtentScrollController _scrollController;

  static const int _minAge = 14;
  static const int _maxAge = 80;
  static const double _itemWidth = 70.0;

  @override
  void initState() {
    super.initState();
    controller = Get.find<SetupMaleController>();
    // Position the scroll so that the default age is centered
    _scrollController = FixedExtentScrollController(
      initialItem: controller.maleAge.value - _minAge,
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            // ── Top Bar ────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () => Get.back(),
                    child: const Icon(
                      Icons.arrow_back,
                      color: Color(0xFF0A0615),
                      size: 24,
                    ),
                  ),
                  const Text(
                    'Step 8 of 9',
                    style: TextStyle(
                      color: Color(0xFF0A0615),
                      fontSize: 16,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(width: 24),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // ── Title ──────────────────────────────────────────────────
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 24),
              child: Text(
                'How Old Are You?',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF0A0615),
                  fontSize: 27,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),

            const Spacer(),

            // ── Big Age Number ──────────────────────────────────────────
            Obx(
              () => Text(
                '${controller.maleAge.value}',
                style: const TextStyle(
                  color: Color(0xFF0A0615),
                  fontSize: 66,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w700,
                  height: 1,
                ),
              ),
            ),

            const SizedBox(height: 16),

            // ── Yellow Triangle Indicator ──────────────────────────────
            SvgPicture.asset('assets/icons/polygon.svg'),

            const SizedBox(height: 23),

            // ── Horizontal Age Picker ──────────────────────────────────
            SizedBox(
              height: 70,
              child: RotatedBox(
                quarterTurns: -1,
                child: ListWheelScrollView.useDelegate(
                  controller: _scrollController,
                  itemExtent: _itemWidth,
                  perspective: 0.002,
                  physics: const FixedExtentScrollPhysics(),
                  onSelectedItemChanged: (index) {
                    controller.setMaleAge(_minAge + index);
                  },
                  childDelegate: ListWheelChildBuilderDelegate(
                    childCount: _maxAge - _minAge + 1,
                    builder: (context, index) {
                      final age = _minAge + index;
                      return RotatedBox(
                        quarterTurns: 1,
                        child: Obx(() {
                          final isSelected = controller.maleAge.value == age;
                          return Container(
                            width: _itemWidth,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? const Color(0xFF0A0615)
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(8),
                              border: isSelected
                                  ? null
                                  : Border.all(
                                      color: const Color(0xFFE5E9EF),
                                      width: 1,
                                    ),
                            ),
                            child: Text(
                              '$age',
                              style: TextStyle(
                                color: isSelected
                                    ? Colors.white
                                    : const Color(0xFF0A0615),
                                fontSize: 22,
                                fontFamily: 'Poppins',
                                fontWeight: isSelected
                                    ? FontWeight.w700
                                    : FontWeight.w500,
                              ),
                            ),
                          );
                        }),
                      );
                    },
                  ),
                ),
              ),
            ),

            const Spacer(flex: 2),

            // ── Next Button ────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.all(24),
              child: CustomButton(
                text: 'Next',
                onPressed: () {
                   Get.to(() => const MaleStepNine());
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}