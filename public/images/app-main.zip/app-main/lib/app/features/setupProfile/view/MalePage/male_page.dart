import 'package:demo_project/app/features/setupProfile/view/MalePage/male_step_two.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class MalePage extends StatelessWidget {
  const MalePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SizedBox.expand(
        child: Stack(
          children: [
            // ── Full-screen Background Image ───────────────────────────
            Positioned.fill(
              child: Image.asset('assets/images/male.png', fit: BoxFit.cover),
            ),

            // ── Gradient Overlay ───────────────────────────────────────
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withValues(alpha: 0.6),
                      Colors.transparent,
                      Colors.transparent,
                      Colors.black.withValues(alpha: 0.8),
                    ],
                    stops: const [0.0, 0.15, 0.7, 1.0],
                  ),
                ),
              ),
            ),

            // ── Top Bar ────────────────────────────────────────────────
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Back button
                    GestureDetector(
                      onTap: () => Get.back(),
                      child: const Icon(
                        Icons.arrow_back,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),

                    // Step indicator
                    const Text(
                      'Step 1 of 9',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                      ),
                    ),

                    // Skip button
                    GestureDetector(
                      onTap: () {
                        // Skip action
                      },
                      child: const Text(
                        'Skip',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // ── Bottom Text ────────────────────────────────────────────
            Positioned(
              left: 0,
              right: 0,
              bottom: 40,
              child: InkWell(
                onTap: () {
                  Get.to(() => MaleStepTwo());
                },
                child: Center(
                  child: Text(
                    'Male',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 27,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                      shadows: [
                        Shadow(
                          color: Colors.black.withValues(alpha: 0.6),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
