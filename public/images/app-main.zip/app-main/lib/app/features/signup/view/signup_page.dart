import 'package:demo_project/app/routes/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:demo_project/app/core/theme/app_colors.dart';
import 'package:demo_project/app/core/widgets/custom_text_field.dart';
import 'package:demo_project/app/core/widgets/custom_button.dart';
import 'package:demo_project/app/features/signup/controller/signup_controller.dart';

class SignupPage extends GetView<SignupController> {
  const SignupPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Form(
            key: controller.formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 60),
                // Title
                const Text(
                  "Sign Up",
                  style: TextStyle(
                    fontSize: 27,
                    fontWeight: FontWeight.w600,
                    color: AppColors.lightTextPrimary,
                    fontFamily: 'Poppins',
                  ),
                ),
                const SizedBox(height: 24),

                // Full Name Field
                CustomTextField(
                  controller: controller.nameController,
                  hintText: "Full Name",
                  keyboardType: TextInputType.name,

                ),
                const SizedBox(height: 16),

                // Email Field
                CustomTextField(
                  controller: controller.emailController,
                  hintText: "Email",
                  keyboardType: TextInputType.emailAddress,

                ),
                const SizedBox(height: 16),

                // Phone Field
                CustomTextField(
                  controller: controller.phoneController,
                  hintText: "Phone",
                  keyboardType: TextInputType.phone,

                ),
                const SizedBox(height: 16),

                // Password Field
                CustomTextField(
                  controller: controller.passwordController,
                  hintText: "Password",
                  isPassword: true,

                ),
                const SizedBox(height: 10),

                // Privacy Policy Checkbox
                Obx(() => Row(
                      children: [
                        SizedBox(
                          height: 24,
                          width: 24,
                          child: Checkbox(
                            value: controller.isPrivacyAccepted.value,
                            onChanged: (value) => controller.togglePrivacy(),
                            activeColor: Colors.black,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: GestureDetector(
                            onTap: controller.togglePrivacy,
                            child: RichText(
                              text: TextSpan(
                                style: const TextStyle(
                                  color: Colors.grey,
                                  fontSize: 13,
                                  fontFamily: 'Poppins',
                                ),
                                children: [
                                  const TextSpan(text: "By continuing you accept our "),
                                  TextSpan(
                                    text: "Privacy Policy",
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.w600,
                                      decoration: TextDecoration.underline,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    )),
                const SizedBox(height: 20),

                // Sign Up Button
                CustomButton(
                  text: "Sign up",
                  onPressed:(){

                    Get.toNamed(AppRoutes.emailVerification);

                  },
                ),

                const SizedBox(height: 24),

                // or divider
                Row(
                  children: [
                    Expanded(child: Divider(color: Color(0xFFE2E8F0), thickness: 1)),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Text(
                        "or continue with",
                        style: TextStyle(
                          color: Color(0xFF90A1B9),
                          fontSize: 14,
                          fontFamily: 'Poppins',
                        ),
                      ),
                    ),
                    Expanded(child: Divider(color: Color(0xFFE2E8F0), thickness: 1)),
                  ],
                ),
                const SizedBox(height: 24),

                // Google Sign In Button
                Container(
                  width: double.infinity,
                  height: 56,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(34),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () {
                        // Google sign in logic
                      },
                      borderRadius: BorderRadius.circular(34),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SvgPicture.asset("assets/icons/google.svg"),
                          const SizedBox(width: 12),
                          const Text(
                            "Sign in with Google",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              color: AppColors.lightTextPrimary,
                              fontFamily: 'Poppins',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 40),

                // Sign In Link
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Already have an account? ",
                      style: TextStyle(
                        color: Color(0xFF404B52),
                        fontSize: 14,
                        fontFamily: 'Poppins',
                      ),
                    ),
                    GestureDetector(
                      onTap: () {


                      },
                      child: const Text(
                        "Sign In",
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 14,
                          color: Color(0xFF000000),
                          decoration: TextDecoration.underline,
                          fontFamily: 'Poppins',
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
