import 'package:get/get.dart';

class HomeController extends GetxController {
  var activeIndex = 2.obs; // Default to 'T 18'
  var selectedBodyFocus = 0.obs; // Default to 'All'
  var selectedTopCategory = 1.obs; // Default to 'Breakfast' based on screenshot
  var selectedTrainingGear = 0.obs; // Default to 'All'

  void changeActiveIndex(int index) {
    activeIndex.value = index;
  }

  void changeBodyFocus(int index) {
    selectedBodyFocus.value = index;
  }

  void changeTopCategory(int index) {
    selectedTopCategory.value = index;
  }

  void changeTrainingGear(int index) {
    selectedTrainingGear.value = index;
  }

  // Weekly Streaks
  var selectedStreakDates = <int>[20, 22, 24].obs;

  void toggleStreakDate(int day) {
    if (selectedStreakDates.contains(day)) {
      selectedStreakDates.remove(day);
    } else {
      selectedStreakDates.add(day);
    }
  }
}
