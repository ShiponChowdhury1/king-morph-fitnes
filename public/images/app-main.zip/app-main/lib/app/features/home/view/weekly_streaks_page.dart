import 'package:demo_project/app/core/widgets/custom_button.dart';
import 'package:demo_project/app/features/home/controller/home_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class WeeklyStreaksPage extends StatelessWidget {
  const WeeklyStreaksPage({super.key});

  @override
  Widget build(BuildContext context) {
    final HomeController controller = Get.find<HomeController>();

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Get.back(),
        ),
        title: const Text(
          'Weekly Streaks',
          style: TextStyle(
            color: Color(0xFF000000),
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
        ),
        centerTitle: false,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Calendar Month Header
            const Center(
              child: Text(
                'February 2026',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Colors.black,
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Weekday Headers
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                'S',
                'M',
                'T',
                'W',
                'T',
                'F',
                'S',
              ].map((day) => _buildDayBox(text: day, isHeader: true)).toList(),
            ),
            const SizedBox(height: 12),

            // Calendar Grid
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 7,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12, // Adjusted to match design
              ),
              itemCount: 28,
              itemBuilder: (context, index) {
                int day = index + 1;
                return Obx(() {
                  bool isSelected = controller.selectedStreakDates.contains(
                    day,
                  );
                  return GestureDetector(
                    onTap: () => controller.toggleStreakDate(day),
                    child: Container(
                      decoration: BoxDecoration(
                        color: isSelected ? Colors.black : Colors.white,
                        border: Border.all(
                          color: isSelected ? Colors.black : Colors.grey[300]!,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        day.toString(),
                        style: TextStyle(
                          color: isSelected ? Colors.white : Colors.black87,
                          fontWeight: isSelected
                              ? FontWeight.bold
                              : FontWeight.w500,
                        ),
                      ),
                    ),
                  );
                });
              },
            ),
            const SizedBox(height: 32),

            // Summary Title
            const Text(
              'Summary',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 16),

            // Workout Cards
            Obx(() {
              if (controller.selectedStreakDates.isEmpty) {
                return const Padding(
                  padding: EdgeInsets.all(20.0),
                  child: Center(child: Text('No dates selected')),
                );
              }

              // Sort dates in descending order
              var sortedDates = controller.selectedStreakDates.toList()
                ..sort((a, b) => b.compareTo(a));

              return Column(
                children: sortedDates
                    .map((day) => _buildWorkoutCard(day))
                    .toList(),
              );
            }),

            const SizedBox(height: 40),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          color: Colors.white,
          child: CustomButton(
            onPressed: () {
              Get.back();
            },
            text: 'Continue',
          ),
        ),
      ),
    );
  }

  Widget _buildDayBox({required String text, bool isHeader = false}) {
    return Container(
      width: 42,
      height: 42,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.grey[200]!),
        borderRadius: BorderRadius.circular(12),
      ),
      alignment: Alignment.center,
      child: Text(
        text,
        style: TextStyle(
          color: Colors.black87,
          fontWeight: isHeader ? FontWeight.w600 : FontWeight.w500,
          fontSize: 14,
        ),
      ),
    );
  }

  Widget _buildWorkoutCard(int day) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$day February 2026 - 1 Workout',
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: Colors.black,
            ),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              _buildIconText('🏃', '5 Exercises'),
              const SizedBox(width: 12),
              _buildIconText('⏱️', '30 Minutes'),
              const SizedBox(width: 12),
              _buildIconText('🔥', '1320 Kcal'),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            height: 110,
            decoration: BoxDecoration(
              color: Color(0xFFF8FAFC),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          'Chest Workout',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Color(0xFF0A0615),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            _buildIconText('⏱️', '60 Minutes', isSmall: true),
                            const SizedBox(width: 12),
                            _buildIconText('🔥', '1320 Kcal', isSmall: true),
                          ],
                        ),
                        const SizedBox(height: 4),
                        _buildIconText('🏃', '5 Exercises', isSmall: true),
                      ],
                    ),
                  ),
                ),
                ClipRRect(
                  borderRadius: const BorderRadius.only(
                    topRight: Radius.circular(16),
                    bottomRight: Radius.circular(16),
                  ),
                  child: Image.asset(
                    'assets/images/chest.png', // The user can change this image path if needed
                    width: 140,
                    height: double.infinity,
                    fit: BoxFit.cover,
                    alignment: Alignment.topCenter,
                    errorBuilder: (context, error, stackTrace) => Container(
                      width: 140,
                      color: Colors.grey[300],
                      child: const Icon(Icons.image, color: Colors.grey),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIconText(String emoji, String text, {bool isSmall = false}) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(emoji, style: TextStyle(fontSize: isSmall ? 10 : 12)),
        const SizedBox(width: 4),
        Text(
          text,
          style: TextStyle(
            fontSize: isSmall ? 11 : 12,
            color: Color(0xFF212020),
            fontWeight: FontWeight.w300,
          ),
        ),
      ],
    );
  }
}
