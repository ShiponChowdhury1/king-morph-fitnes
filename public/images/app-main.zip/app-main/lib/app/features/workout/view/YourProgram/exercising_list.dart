import 'package:demo_project/app/features/workout/view/YourProgram/barbell_bench_press.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:demo_project/app/core/widgets/custom_button.dart';

class ExercisingList extends StatelessWidget {
  ExercisingList({super.key});

  final List<Map<String, dynamic>> exercises = [
    {
      'title': 'Barbell Bench Press',
      'stats': '4 sets  •  8-10 reps  •  90s rest',
      'tag': 'Chest',
    },
    {
      'title': 'Incline Dumbbell Press',
      'stats': '4 sets  •  10-12 reps  •  75s rest',
      'tag': 'Chest',
    },
    {
      'title': 'Cable Flyes',
      'stats': '3 sets  •  12-15 reps  •  60s rest',
      'tag': 'Chest',
    },
    {
      'title': 'Tricep Dips',
      'stats': '3 sets  •  10-12 reps  •  60s rest',
      'tag': 'Chest',
    },
    {
      'title': 'Overhead Cable Extension',
      'stats': '3 sets  •  12-15 reps  •  60s rest',
      'tag': 'Chest',
    },
  ];

  late final RxList<bool> selectedItems = List.generate(
    exercises.length,
    (_) => false,
  ).obs;

  void _toggleSelection(int index) {
    selectedItems[index] = !selectedItems[index];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Get.back(),
        ),
        title: const Text(
          'Chest & Triceps',
          style: TextStyle(
            fontFamily: 'Poppins',
            color: Colors.black,
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
        ),
        centerTitle: false,
        titleSpacing: 0,
      ),
      body: Stack(
        children: [
          Obx(() {
            final selectedCount = selectedItems.where((e) => e).length;
            final progressValue = exercises.isEmpty
                ? 0.0
                : selectedCount / exercises.length;

            return ListView(
              padding: const EdgeInsets.only(
                left: 20,
                right: 20,
                top: 16,
                bottom: 100,
              ),
              children: [
                const Text(
                  'Chest & Triceps',
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 24,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF0D0D0D),
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    SvgPicture.asset('assets/icons/clock_fill.svg', height: 14),
                    const SizedBox(width: 6),
                    const Text(
                      '60 min',
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: Color(0xFF666666),
                      ),
                    ),
                    const SizedBox(width: 16),
                    SvgPicture.asset(
                      'assets/icons/progress_file.svg',
                      height: 14,
                    ),
                    const SizedBox(width: 6),
                    const Text(
                      '450 kcal',
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: Color(0xFF666666),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Progress',
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: Color(0xFF666666),
                      ),
                    ),
                    Text(
                      '$selectedCount / ${exercises.length}',
                      style: const TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                // Linear Progress
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: progressValue == 0.0
                        ? 0.05
                        : progressValue, // Ensure a slight bar at 0 for visual style, or actual progress
                    minHeight: 6,
                    backgroundColor: const Color(0xFFF0F0F0),
                    valueColor: const AlwaysStoppedAnimation<Color>(
                      Colors.black,
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                ...List.generate(exercises.length, (index) {
                  final exercise = exercises[index];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: _buildExerciseCard(
                      title: exercise['title'] as String,
                      stats: exercise['stats'] as String,
                      tag: exercise['tag'] as String,
                      isSelected: selectedItems[index],
                      onTap: () => _toggleSelection(index),
                    ),
                  );
                }),
              ],
            );
          }),

          // Sticky Bottom Button
          Positioned(
            left: 20,
            right: 20,
            bottom: 24,
            child: CustomButton(
              text: 'Choose',
              onPressed: () {
                // Handle choose action
                Get.to(() => BarbellBenchPress());
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildExerciseCard({
    required String title,
    required String stats,
    required String tag,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFFE0E0E0), width: 1),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: isSelected
                  ? const Icon(
                      Icons.check_circle,
                      color: Colors.black, // Primary color from the app design
                      size: 24,
                    )
                  : Container(
                      width: 24,
                      height: 24,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: const Color(0xFFE0E0E0),
                          width: 1.5,
                        ),
                      ),
                    ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF0D0D0D),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    stats,
                    style: const TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Color(0xFF666666),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFF000000).withValues(alpha: 0.10),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      tag,
                      style: const TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 12,
                        fontWeight: FontWeight.w400,
                        color: Color(0xFF000000),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SvgPicture.asset('assets/icons/play.svg'),
          ],
        ),
      ),
    );
  }
}
