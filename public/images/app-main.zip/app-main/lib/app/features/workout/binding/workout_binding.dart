import 'package:demo_project/app/features/workout/controller/workout_controller.dart';
import 'package:get/get.dart';

class WorkoutBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<WorkoutController>(() => WorkoutController());
  }
}