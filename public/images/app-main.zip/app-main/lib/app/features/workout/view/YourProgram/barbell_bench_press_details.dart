import 'package:demo_project/app/features/workout/view/YourProgram/incline_dumbbell_press.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class BarbellBenchPressDetails extends StatelessWidget {
  BarbellBenchPressDetails({super.key});

  final RxInt selectedTab = 0.obs;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Get.back(),
        ),
      ),
      body: Stack(
        children: [
          ListView(
            padding: const EdgeInsets.only(
              left: 20,
              right: 20,
              top: 16,
              bottom: 120, // space for bottom nav
            ),
            children: [
              // Image Card
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0xFFE0E0E0)),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Image.asset(
                        'assets/images/barbell.png',
                        fit: BoxFit.contain,
                        width: double.infinity,
                        height: 200,
                      ),
                      Container(
                        width: 56,
                        height: 56,
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.3),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.play_arrow,
                          color: Colors.white,
                          size: 32,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // Progress text
              const Text(
                '1/5',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Colors.black,
                ),
              ),
              const SizedBox(height: 8),

              // Title
              const Text(
                'Barbell Bench Press',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 24,
                  fontWeight: FontWeight.w700,
                  color: Colors.black,
                ),
              ),
              const SizedBox(height: 40),

              // Stats
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildStatItem('15x', 'Reps'),
                  _buildStatItem('3x', 'Sets'),
                  _buildStatItemWithStackedLabel('20', 'Sec', 'Rest'),
                ],
              ),
              const SizedBox(height: 32),

              // Tabs
              Obx(() => _buildTabs()),
              const SizedBox(height: 24),

              // Tab Content based on selection
              Obx(() {
                if (selectedTab.value == 0) return _buildHowToDoTab();
                if (selectedTab.value == 1) return _buildMuscleTab();
                return _buildTipsTab();
              }),
            ],
          ),

          // Bottom Navigation
          Positioned(
            left: 20,
            right: 20,
            bottom: 24,
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: const BoxDecoration(
                    color: Color(0xFF888888),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.chevron_left, color: Colors.white),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: InkWell(
                    onTap: () {
                      Get.to(() => InclineDumbbellPress());
                    },
                    child: Container(
                      height: 48,
                      decoration: BoxDecoration(
                        color: Colors.black,
                        borderRadius: BorderRadius.circular(24),
                      ),
                      alignment: Alignment.center,
                      child: const Text(
                        'Next',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                InkWell(
                  onTap: () {
                    Get.to(() => InclineDumbbellPress());
                  },
                  child: Container(
                    width: 48,
                    height: 48,
                    decoration: const BoxDecoration(
                      color: Colors.black,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.chevron_right, color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabs() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFF0F0F0),
        borderRadius: BorderRadius.circular(8),
      ),
      padding: const EdgeInsets.all(4),
      child: Row(
        children: [
          Expanded(child: _buildTabButton(0, 'How to do')),
          Expanded(child: _buildTabButton(1, 'Muscle')),
          Expanded(child: _buildTabButton(2, 'Tips')),
        ],
      ),
    );
  }

  Widget _buildTabButton(int index, String title) {
    final isSelected = selectedTab.value == index;
    return GestureDetector(
      onTap: () => selectedTab.value = index,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? Colors.black : Colors.transparent,
          borderRadius: BorderRadius.circular(6),
        ),
        alignment: Alignment.center,
        child: Text(
          title,
          style: TextStyle(
            fontFamily: 'Poppins',
            fontSize: 14,
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
            color: isSelected ? Colors.white : const Color(0xFF666666),
          ),
        ),
      ),
    );
  }

  Widget _buildHowToDoTab() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildInstructionsSection(),
        const SizedBox(height: 24),
        _buildTargetSection(),
        const SizedBox(height: 24),
        _buildImageSection(),
        const SizedBox(height: 24),
        _buildCommonMistakesSection(),
      ],
    );
  }

  Widget _buildMuscleTab() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildTargetSection(),
        const SizedBox(height: 24),
        _buildImageSection(),
      ],
    );
  }

  Widget _buildTipsTab() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildUsefulTipsSection(),
        const SizedBox(height: 16),
        _buildMistakeItem(
          '1 Improper hand placement',
          'Placing your hands too wide or too close together can put unnecessary strain on your wrists and elbows. Keep your hands shoulder-width apart and directly under your shoulders.',
        ),
        _buildMistakeItem(
          '2 Excessive lifting of the hips or collapsing of the back',
          'Allowing your back to sag or lifting your hips too high during Push-ups can put undue stress on your spine and increase the risk of injury. Keep your body in a straight line from head to heels.',
        ),
        _buildMistakeItem(
          '3 Not engaging the core',
          'It requires the core muscles to be engaged throughout the entire exercise. If the core is not engaged, it can lead to poor form and an ineffective workout.',
        ),
        _buildMistakeItem(
          '4 Allowing the elbows to flare out to the sides',
          'This places unnecessary stress on the shoulder joints and can reduce the effectiveness of the exercise.',
        ),
      ],
    );
  }

  Widget _buildInstructionsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: const [
        Text(
          'INSTRUCTIONS',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        SizedBox(height: 12),
        Text(
          'Start in the regular push-up position but with your hands elevated on a chair or bench.\nThen push your body up down using your arm strength.\nRemember to keep your body straight.',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontSize: 14,
            color: Color(0xFF666666),
            height: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildTargetSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Where it targets',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            _buildTargetTag('Chest'),
            _buildTargetTag('Shoulders'),
            _buildTargetTag('Triceps'),
          ],
        ),
      ],
    );
  }

  Widget _buildImageSection() {
    return Center(
      child: Image.asset(
        'assets/images/singaletion.png',
        height: 200,
        fit: BoxFit.contain,
      ),
    );
  }

  Widget _buildCommonMistakesSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'COMMON MISTAKES',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        const SizedBox(height: 16),
        _buildMistakeItem(
          '1 Improper hand placement',
          'Placing your hands too wide or too close together can put unnecessary strain on your wrists and elbows. Keep your hands shoulder-width apart and directly under your shoulders.',
        ),
        _buildMistakeItem(
          '2 Excessive lifting of the hips or collapsing of the back',
          'Allowing your back to sag or lifting your hips too high during Push-ups can put undue stress on your spine and increase the risk of injury. Keep your body in a straight line from head to heels.',
        ),
        _buildMistakeItem(
          '3 Not engaging the core',
          'It requires the core muscles to be engaged throughout the entire exercise. If the core is not engaged, it can lead to poor form and an ineffective workout.',
        ),
        _buildMistakeItem(
          '4 Allowing the elbows to flare out to the sides',
          'This places unnecessary stress on the shoulder joints and can reduce the effectiveness of the exercise.',
        ),
      ],
    );
  }

  Widget _buildUsefulTipsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Useful Tips',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        const SizedBox(height: 12),
        _buildBulletPoint(
          'Inhale as you lower your body towards the elevated surface.',
        ),
        _buildBulletPoint(
          'Exhale as you push back up to the starting position.',
        ),
      ],
    );
  }

  Widget _buildTargetTag(String text) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Color(0xFFE2EDFF),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: Color(0xFF0049FF)),
      ),
      child: Text(
        text,
        style: const TextStyle(
          fontFamily: 'Poppins',
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: Colors.blue,
        ),
      ),
    );
  }

  Widget _buildMistakeItem(String title, String desc) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontFamily: 'Poppins',
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: Colors.black,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            desc,
            style: const TextStyle(
              fontFamily: 'Poppins',
              fontSize: 12,
              color: Color(0xFF666666),
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBulletPoint(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '•',
            style: TextStyle(
              fontSize: 14,
              color: Color(0xFF666666),
              height: 1.5,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(
                fontFamily: 'Poppins',
                fontSize: 14,
                color: Color(0xFF666666),
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String value, String label) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.baseline,
      textBaseline: TextBaseline.alphabetic,
      children: [
        Text(
          value,
          style: const TextStyle(
            fontFamily: 'Poppins',
            fontSize: 36,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        const SizedBox(width: 6),
        Text(
          label,
          style: const TextStyle(
            fontFamily: 'Poppins',
            fontSize: 16,
            fontWeight: FontWeight.w500,
            color: Color(0xFF666666),
          ),
        ),
      ],
    );
  }

  Widget _buildStatItemWithStackedLabel(
    String value,
    String topLabel,
    String bottomLabel,
  ) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          value,
          style: const TextStyle(
            fontFamily: 'Poppins',
            fontSize: 36,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        const SizedBox(width: 6),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              topLabel,
              style: const TextStyle(
                fontFamily: 'Poppins',
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: Color(0xFF666666),
                height: 1.1,
              ),
            ),
            Text(
              bottomLabel,
              style: const TextStyle(
                fontFamily: 'Poppins',
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: Color(0xFF666666),
                height: 1.1,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
