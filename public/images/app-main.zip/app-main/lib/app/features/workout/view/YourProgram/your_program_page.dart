import 'package:demo_project/app/features/workout/view/YourProgram/details_page.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';


class YourProgramPage extends StatelessWidget {
  const YourProgramPage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> dummyPrograms = [
      {
        'day': 'Saturday',
        'tag': 'Today',
        'tagColor': Colors.black,
        'title': 'Leg Day',
        'exercises': 5,
        'minutes': 55,
        'calories': 380,
        'isRest': false,
      },
      {
        'day': 'Sunday',
        'title': 'Chest & Back',
        'exercises': 5,
        'minutes': 55,
        'calories': 380,
        'isRest': false,
      },
      {
        'day': 'Monday',
        'title': 'Biceps & Triceps',
        'exercises': 4,
        'minutes': 50,
        'calories': 350,
        'isRest': false,
      },
      {
        'day': 'Tuesday',
        'title': 'Shoulders',
        'exercises': 6,
        'minutes': 60,
        'calories': 450,
        'isRest': false,
      },
      {
        'day': 'Wednesday',
        'title': 'Abs',
        'exercises': 5,
        'minutes': 45,
        'calories': 300,
        'isRest': false,
      },
      {
        'day': 'Thursday',
        'title': 'Cardio',
        'exercises': 5,
        'minutes': 45,
        'calories': 300,
        'isRest': false,
      },
      {
        'day': 'Friday',
        'tag': 'Rest',
        'tagColor': Colors.black,
        'title': 'Rest & Recovery Day',
        'isRest': true,
      },
    ];

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Your Program',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Muscle Gain • Mesomorph • Gym-based',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 13,
                  color: Color(0xFF808080),
                ),
              ),
              const SizedBox(height: 24),
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: dummyPrograms.length,
                itemBuilder: (context, index) {
                  final program = dummyPrograms[index];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: _buildProgramCard(
                      onTap: () {
                        Get.to(()=> DetailsPage());
                      },
                      day: program['day'] as String,
                      tag: program['tag'] as String?,
                      tagColor: program['tagColor'] as Color?,
                      title: program['title'] as String,
                      exercises: program['exercises'] as int?,
                      minutes: program['minutes'] as int?,
                      calories: program['calories'] as int?,
                      isRest: program['isRest'] as bool? ?? false,
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProgramCard({
    required String day,
    String? tag,
    Color? tagColor,
    required String title,
    required void Function()? onTap,
    int? exercises,
    int? minutes,
    int? calories,
    bool isRest = false,
  }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey.shade200, width: 1),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      day,
                      style: const TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.black,
                      ),
                    ),
                    if (tag != null) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: tagColor ?? Colors.black,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          tag,
                          style: const TextStyle(
                            fontFamily: 'Poppins',
                            fontSize: 10,
                            fontWeight: FontWeight.w500,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  title,
                  style: const TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.black,
                  ),
                ),
                if (!isRest) ...[
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      const Text('🏃', style: TextStyle(fontSize: 12)),
                      const SizedBox(width: 4),
                      Text(
                        '$exercises Exercises',
                        style: const TextStyle(
                          fontFamily: 'Poppins',
                          fontSize: 11,
                          color: Color(0xFF666666),
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Text('🕒', style: TextStyle(fontSize: 12)),
                      const SizedBox(width: 4),
                      Text(
                        '$minutes min',
                        style: const TextStyle(
                          fontFamily: 'Poppins',
                          fontSize: 11,
                          color: Color(0xFF666666),
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Text('🔥', style: TextStyle(fontSize: 12)),
                      const SizedBox(width: 4),
                      Text(
                        '$calories kcal',
                        style: const TextStyle(
                          fontFamily: 'Poppins',
                          fontSize: 11,
                          color: Color(0xFF666666),
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
            Icon(Icons.chevron_right, color: Colors.grey.shade400),
          ],
        ),
      ),
    );
  }
}
