import 'package:demo_project/app/features/workout/view/YourProgram/exercising_list.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

class StartExercisingPage extends StatelessWidget {
  const StartExercisingPage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> daysData = [
      {
        'day': 'Monday',
        'tag': 'Today',
        'title': 'Chest & Triceps',
        'exercises': 5,
        'minutes': 60,
        'calories': 450,
      },
      {
        'day': 'Tuesday',
        'title': 'Back & Biceps',
        'exercises': 5,
        'minutes': 65,
        'calories': 420,
      },
      {
        'day': 'Wednesday',
        'title': 'Rest or Cardio',
        'isRest': true,
        'restText': 'Rest or light cardio',
      },
      {
        'day': 'Thursday',
        'title': 'Shoulders & Abs',
        'exercises': 5,
        'minutes': 55,
        'calories': 380,
      },
      {
        'day': 'Friday',
        'title': 'Legs',
        'exercises': 5,
        'minutes': 70,
        'calories': 520,
      },
    ];

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Get.back(),
        ),
        title: const Text(
          'Your Program',
          style: TextStyle(
            fontFamily: 'Poppins',
            color: Colors.black,
            fontSize: 18,
            fontWeight: FontWeight.w500,
          ),
        ),
        centerTitle: false,
        titleSpacing: 0,
      ),
      body: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        itemCount: daysData.length,
        separatorBuilder: (context, index) => const SizedBox(height: 16),
        itemBuilder: (context, index) {
          final data = daysData[index];
          return _buildDayCard(
            onTap: () {
              Get.to(() => ExercisingList());
            },
            day: data['day'] as String,
            tag: data['tag'] as String?,
            title: data['title'] as String,
            exercises: data['exercises'] as int?,
            minutes: data['minutes'] as int?,
            calories: data['calories'] as int?,
            isRest: data['isRest'] as bool? ?? false,
            restText: data['restText'] as String?,
          );
        },
      ),
    );
  }

  Widget _buildDayCard({
    required String day,
    String? tag,
    required String title,
    int? exercises,
    int? minutes,
    int? calories,
    bool isRest = false,
    String? restText,
    required void Function()? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Color(0xFFE0E0E0), width: 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  day,
                  style: const TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: Colors.black,
                  ),
                ),
                if (tag != null) ...[
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFF000000).withValues(alpha: 0.20),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      tag,
                      style: const TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 10,
                        fontWeight: FontWeight.w500,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ],
              ],
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    color: Color(0xFF0D0D0D),
                  ),
                ),
                const Icon(Icons.chevron_right, color: Colors.grey, size: 20),
              ],
            ),
            const SizedBox(height: 8),
            if (isRest)
              Text(
                restText ?? '',
                style: const TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: Color(0xFF666666),
                ),
              )
            else
              Row(
                children: [
                  Text(
                    '$exercises exercises',
                    style: const TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 12,
                      color: Color(0xFF666666),
                    ),
                  ),
                  const SizedBox(width: 12),
                  SvgPicture.asset('assets/icons/clock.svg', height: 12),
                  const SizedBox(width: 4),
                  Text(
                    '$minutes min',
                    style: const TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 12,
                      color: Color(0xFF666666),
                    ),
                  ),
                  const SizedBox(width: 12),
                  SvgPicture.asset('assets/icons/fire.svg', height: 12),
                  const SizedBox(width: 4),
                  Text(
                    '$calories kcal',
                    style: const TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 12,
                      color: Color(0xFF666666),
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
