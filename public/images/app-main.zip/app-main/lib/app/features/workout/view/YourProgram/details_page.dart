import 'package:demo_project/app/core/widgets/custom_button.dart';
import 'package:demo_project/app/features/workout/view/YourProgram/start_exercising_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

class DetailsPage extends StatelessWidget {
  const DetailsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Get.back(),
        ),
        title: const Text(
          'Your Program',
          style: TextStyle(
            fontFamily: 'Poppins',
            color: Colors.black,
            fontSize: 18,
            fontWeight: FontWeight.w500,
          ),
        ),
        centerTitle: false,
        titleSpacing: 0,
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: const EdgeInsets.only(
              left: 20,
              right: 20,
              top: 16,
              bottom: 100,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Video Player Placeholder
                Container(
                  height: 200,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.asset(
                          'assets/images/chest.png',
                          fit: BoxFit.cover,
                          alignment: Alignment.topCenter,
                        ),
                        // Play button overlay
                        Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 48,
                                height: 48,
                                decoration: BoxDecoration(
                                  color: Colors.black.withValues(alpha: 0.4),
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(
                                  Icons.play_arrow,
                                  color: Colors.white,
                                  size: 32,
                                ),
                              ),
                              const SizedBox(height: 8),
                              const Text(
                                'Video demonstration',
                                style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontSize: 11,
                                  color: Colors.black,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                // Stats Row
                Row(
                  children: [
                    Expanded(child: _buildStatBox('4', 'Sets')),
                    const SizedBox(width: 12),
                    Expanded(child: _buildStatBox('8-10', 'Reps')),
                    const SizedBox(width: 12),
                    Expanded(child: _buildStatBox('30s', 'Rest')),
                  ],
                ),
                const SizedBox(height: 16),

                // Title and Description
                const Text(
                  'Full Body workout training program',
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 20,
                    fontWeight: FontWeight.w500,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'A full-body workout is a training routine that targets all major muscle groups—chest, back, shoulders, arms, legs, and core—in a single session. Ideal for all fitness levels, it typically includes 4-6 compound exercises, such as squats, deadlifts, and presses, usually performed 2-3 times a week to maximize strength, muscle growth, and efficiency.',
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 12,
                    color: Color(0xFF565656),
                    fontWeight: FontWeight.w400,
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 16),

                // Instructions
                const Text(
                  'Instructions',
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 12),
                _buildInstructionItem(
                  1,
                  'Lie flat on a bench with your feet on the floor',
                ),
                _buildInstructionItem(
                  2,
                  'Grip the bar slightly wider than shoulder width',
                ),
                _buildInstructionItem(3, 'Lower the bar to your mid-chest'),
                _buildInstructionItem(
                  4,
                  'Press the bar back up to the starting position',
                ),
                const SizedBox(height: 10),

                // Pro Tip Box
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Color(0xFFD4AF37).withValues(alpha: 0.10),
                        Color(0xFF000000).withValues(alpha: 0.0),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Color(0xFFD4AF37).withValues(alpha: 0.20),
                      width: 1,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '💡 Pro Tip',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontSize: 16,
                          fontWeight: FontWeight.w400,
                          color: Colors.black,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Focus on proper form over heavy weight. Control the movement and feel the muscle working throughout the entire range of motion.',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontSize: 12,
                          fontWeight: FontWeight.w400,
                          color: Color(0xFF000000),
                          height: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // Weeks
                _buildWeekCard(
                  title: 'Week one',
                  minutes: 60,
                  calories: 1320,
                  exercises: 5,
                  imagePath: 'assets/images/chest.png',
                ),
                const SizedBox(height: 12),
                _buildWeekCard(
                  title: 'Week Two',
                  minutes: 60,
                  calories: 1320,
                  exercises: 5,
                  imagePath: 'assets/images/chest.png',
                ),
                const SizedBox(height: 12),
                _buildWeekCard(
                  title: 'Week Three',
                  minutes: 60,
                  calories: 1320,
                  exercises: 5,
                  imagePath: 'assets/images/chest.png',
                ),
                const SizedBox(height: 12),
                _buildWeekCard(
                  title: 'Week Four',
                  minutes: 60,
                  calories: 1320,
                  exercises: 5,
                  imagePath: 'assets/images/chest.png',
                ),
              ],
            ),
          ),

          // Sticky Bottom Button
          Positioned(
            left: 20,
            right: 20,
            bottom: 24,
            child: CustomButton(text: 'Start Exercising', onPressed: () {
              Get.to(()=> StartExercisingPage());
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildStatBox(String value, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
        color: const Color(0xFFF3F3F3),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Text(
            value,
            style: const TextStyle(
              fontFamily: 'Poppins',
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: Colors.black,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(
              fontFamily: 'Poppins',
              fontSize: 11,
              fontWeight: FontWeight.w400,
              color: Color(0xFF3A3A3A),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInstructionItem(int number, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 21,
            height: 21,
            decoration: BoxDecoration(
              color: Color(0xFF000000).withValues(alpha: 0.58),
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: Text(
              number.toString(),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 10,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(
                fontFamily: 'Poppins',
                fontSize: 14,
                fontWeight: FontWeight.w400,
                color: Color(0xFF000000),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWeekCard({
    required String title,
    required int minutes,
    required int calories,
    required int exercises,
    required String imagePath,
  }) {
    return Container(
      height: 105,
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF0A0615),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      SvgPicture.asset('assets/icons/clock.svg'),
                      const SizedBox(width: 4),
                      Text(
                        '$minutes Minutes',
                        style: const TextStyle(
                          fontFamily: 'Poppins',
                          fontSize: 12,
                          fontWeight: FontWeight.w300,
                          color: Color(0xFF212020),
                        ),
                      ),
                      const SizedBox(width: 12),
                      SvgPicture.asset('assets/icons/fire.svg'),
                      const SizedBox(width: 4),
                      Text(
                        '$calories Kcal',
                        style: const TextStyle(
                          fontFamily: 'Poppins',
                          fontSize: 12,
                          fontWeight: FontWeight.w300,
                          color: Color(0xFF212020),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      SvgPicture.asset('assets/icons/exercise.svg'),
                      const SizedBox(width: 4),
                      Text(
                        '$exercises Exercises',
                        style: const TextStyle(
                          fontFamily: 'Poppins',
                          fontSize: 12,
                          fontWeight: FontWeight.w300,
                          color: Color(0xFF212020),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          ClipRRect(
            borderRadius: const BorderRadius.only(
              topRight: Radius.circular(12),
              bottomRight: Radius.circular(12),
            ),
            child: Image.asset(
              imagePath,
              width: 140,
              height: double.infinity,
              fit: BoxFit.cover,
            ),
          ),
        ],
      ),
    );
  }
}
