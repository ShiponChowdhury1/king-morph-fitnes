import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  // ─── Primary ─────────────────────────────────────────────────────────────
  static const Color primary = Color(0xFF1565C0);       // Blue accent (card border)
  static const Color primaryLight = Color(0xFF1E88E5);  // Lighter blue
  static const Color primaryDark = Color(0xFF0D47A1);   // Deeper blue

  // ─── Secondary ───────────────────────────────────────────────────────────
  static const Color secondary = Color(0xFF26A69A);
  static const Color secondaryLight = Color(0xFF64D8CB);
  static const Color secondaryDark = Color(0xFF00766C);

  // ─── Status ──────────────────────────────────────────────────────────────
  static const Color error = Color(0xFFD32F2F);
  static const Color success = Color(0xFF388E3C);
  static const Color warning = Color(0xFFF57C00);

  // =========================================================================
  // LIGHT THEME  (extracted from demo screen)
  // =========================================================================

  // Backgrounds
  static const Color lightBackground = Color(0xFFFFFFFF);   // Main page bg
  static const Color lightSurface = Color(0xFFF5F5F5);      // Stats / info cards
  static const Color lightCardBg = Color(0xFFFFFFFF);       // Recipe card bg
  static const Color lightTagBg = Color(0xFFEEEEEE);        // Pill / tag chips

  // Text
  static const Color lightTextPrimary = Color(0xFF0A0615);
  // Title, body text
  static const Color lightTextSecondary = Color(0xFF616161); // Sub-labels, tag text
  static const Color lightTextHint = Color(0xFFBDBDBD);     // Placeholder text

  // Borders & Dividers
  static const Color lightBorder = Color(0xFFE0E0E0);       // Card borders
  static const Color lightDivider = Color(0xFFEEEEEE);      // Section dividers

  // Button
  static const Color lightButtonBg = Color(0xFF1A1A1A);     // "Add to Meal Plan" btn
  static const Color lightButtonText = Color(0xFFFFFFFF);   // Button label

  // Icon / accent
  static const Color lightIcon = Color(0xFF616161);
  static const Color lightAccentBorder = Color(0xFF1565C0); // Highlighted image border

  // =========================================================================
  // DARK THEME  (derived from demo screen palette for dark mode)
  // =========================================================================

  // Backgrounds
  static const Color darkBackground = Color(0xFF1A1A1A);    // Main page bg
  static const Color darkSurface = Color(0xFF252525);       // Stats / info cards
  static const Color darkCardBg = Color(0xFF2C2C2C);        // Recipe card bg
  static const Color darkTagBg = Color(0xFF3A3A3A);         // Pill / tag chips

  // Text
  static const Color darkTextPrimary = Color(0xFFEEEEEE);   // Title, body text
  static const Color darkTextSecondary = Color(0xFF9E9E9E);  // Sub-labels, tag text
  static const Color darkTextHint = Color(0xFF616161);      // Placeholder text

  // Borders & Dividers
  static const Color darkBorder = Color(0xFF3A3A3A);        // Card borders
  static const Color darkDivider = Color(0xFF2E2E2E);       // Section dividers

  // Button
  static const Color darkButtonBg = Color(0xFFEEEEEE);      // "Add to Meal Plan" btn
  static const Color darkButtonText = Color(0xFF1A1A1A);    // Button label

  // Icon / accent
  static const Color darkIcon = Color(0xFF9E9E9E);
  static const Color darkAccentBorder = Color(0xFF1E88E5);  // Highlighted image border

  // ─── Backwards-compatible aliases ────────────────────────────────────────
  // (keeps existing code using these names from breaking)
  static const Color background = lightBackground;
  static const Color surface = lightSurface;
  static const Color textPrimary = lightTextPrimary;
  static const Color textSecondary = lightTextSecondary;
  static const Color textHint = lightTextHint;
}
